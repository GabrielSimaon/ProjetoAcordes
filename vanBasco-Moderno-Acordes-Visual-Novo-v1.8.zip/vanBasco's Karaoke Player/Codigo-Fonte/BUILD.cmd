@echo off
setlocal
cd /d "%~dp0"
windres app.rc -O coff -o app.o
if errorlevel 1 exit /b 1
g++ -std=c++17 -O2 -static -shared -Wl,--kill-at native_theme.cpp -o ..\VisualModerno.dll -luxtheme -lshell32 -luser32 -lgdi32
if errorlevel 1 exit /b 1
g++ -std=c++17 -O2 -static -municode -mwindows acordes.cpp app.o -o ..\Acordes.exe -lgdiplus -lcomdlg32 -lshell32 -ladvapi32 -luser32 -lgdi32
if errorlevel 1 exit /b 1
echo Compilado. Use MinGW-w64 de 32 bits com g++ e windres no PATH.
