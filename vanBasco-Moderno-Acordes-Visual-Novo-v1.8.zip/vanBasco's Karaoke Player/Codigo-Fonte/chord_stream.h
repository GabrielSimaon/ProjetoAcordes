#pragma once
#include "chords.h"
#include <cstdint>
namespace music {
using Notes=std::array<double,128>;
inline Chord simplify(Chord c){
 if(!c.valid())return c;
 c.kind=basicKind(c.kind);
 c.bass=c.root;return c;
}
inline Chord transposed(Chord c,int semitones){if(c.valid()){c.root=(c.root+semitones%12+12)%12;if(c.bass>=0)c.bass=(c.bass+semitones%12+12)%12;}return c;}
// Do not add successive melody notes together to invent a chord.
// Each channel is assessed separately; no forced minimum display duration.
class ChordStream {
 Chord shown,candidate;std::uint32_t candidateAt=0,lastGood=0,lastValid=0;
 bool simple=true,haveGood=false;unsigned settle=160;
 int selected=-1,pendingChannel=-1;std::uint32_t channelSince=0;
 Notes stableNotes{};
 Chord examine(const Notes& n){
  Chord c=detect(n,shown,true);return simple?simplify(c):c;
 }
 Chord commit(std::uint32_t now,Chord found){
  if(!found.valid()){
   // Short gaps retain the diagram, but prolonged uncertainty is made explicit.
   if(candidate.valid()&&now-lastValid>80)candidate={};
   if(haveGood&&now-lastGood>1800){shown={};haveGood=false;}
   return shown;
  }
  lastGood=now;haveGood=true;lastValid=now;
  if(same(found,shown)){candidate={};return shown;}
  if(!same(found,candidate)){candidate=found;candidateAt=now;}
  if(now-candidateAt>=settle){shown=found;candidate={};}
  return shown;
 }
public:
 void reset(){shown={};candidate={};candidateAt=lastGood=lastValid=0;haveGood=false;selected=pendingChannel=-1;stableNotes.fill(0);}
 void seed(Chord c,std::uint32_t now){reset();shown=c;haveGood=c.valid();lastGood=lastValid=now;}
 void suspend(){candidate={};}
 void settings(bool simplified,bool slow){simple=simplified;settle=slow?320:160;reset();}
 Chord value()const{return shown;}
 int source()const{return selected;}
 const Notes& sourceNotes()const{return stableNotes;}
 Chord update(std::uint32_t now,const Notes& notes){return commit(now,examine(notes));}
 Chord updateChannels(std::uint32_t now,const std::array<Notes,16>& channels,int manual=-1){
  if(manual>=0){selected=manual;stableNotes=channels[manual];return update(now,stableNotes);}
  Chord chosen;int best=-1;double score=-1e9;
  for(int ch=0;ch<16;++ch){Chord c=examine(channels[ch]);if(!c.valid())continue;
   int voices=0;double energy=0;for(double n:channels[ch])if(n>.12){++voices;energy+=n;}
   double rank=c.confidence*4+std::min(voices,6)*.12+energy*.025+(ch==selected?1.5:0);
   if(rank>score){score=rank;best=ch;chosen=c;}
  }
  if(best<0){stableNotes.fill(0);pendingChannel=-1;return commit(now,{});}
  if(selected>=0&&best!=selected){
   if(pendingChannel!=best){pendingChannel=best;channelSince=now;}
   if(now-channelSince<360)return commit(now,{});
  }
  if(selected!=best){candidate={};selected=best;}pendingChannel=-1;
  stableNotes=channels[best];return commit(now,chosen);
 }
};
}
