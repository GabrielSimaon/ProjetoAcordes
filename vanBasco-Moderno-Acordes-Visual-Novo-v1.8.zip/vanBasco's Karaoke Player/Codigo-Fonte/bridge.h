#pragma once
#ifndef UNICODE
#define UNICODE
#define _UNICODE
#endif
#include <windows.h>
#include <tlhelp32.h>
#include <wincrypt.h>
#include <string>
#include <array>
#include <fstream>
#include <cstdint>

struct Snapshot {
 std::array<double,128> notes{};std::array<std::array<double,128>,16> channels{};
 uint32_t tick=0,playerId=0,division=0;std::wstring file;
 int transpose=0;bool playing=false;unsigned muted=0,drums=512;
};
inline std::wstring folder(){wchar_t p[32768];GetModuleFileNameW(nullptr,p,32768);std::wstring s=p;return s.substr(0,s.find_last_of(L"\\/")+1);}
inline std::string sha256(const std::wstring&path){
 HANDLE f=CreateFileW(path.c_str(),GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,nullptr,OPEN_EXISTING,0,nullptr);
 if(f==INVALID_HANDLE_VALUE)return "";
 HCRYPTPROV provider=0;HCRYPTHASH hash=0;std::string out;
 if(CryptAcquireContextW(&provider,nullptr,nullptr,PROV_RSA_AES,CRYPT_VERIFYCONTEXT)&&CryptCreateHash(provider,CALG_SHA_256,0,0,&hash)){
  BYTE block[16384],digest[32];DWORD n=0;bool ok=true;
  for(;;){if(!ReadFile(f,block,sizeof(block),&n,nullptr)){ok=false;break;}if(!n)break;if(!CryptHashData(hash,block,n,0)){ok=false;break;}}
  n=32;if(ok&&CryptGetHashParam(hash,HP_HASHVAL,digest,&n,0)){const char*h="0123456789abcdef";for(unsigned i=0;i<n;++i){out+=h[digest[i]>>4];out+=h[digest[i]&15];}}
 }
 if(hash)CryptDestroyHash(hash);if(provider)CryptReleaseContext(provider,0);CloseHandle(f);return out;
}
class Bridge {
 HANDLE process=nullptr;DWORD pid=0;HWND mainWindow=nullptr;
 bool read(uint32_t at,void*data,size_t n){SIZE_T got=0;return at>=0x10000&&ReadProcessMemory(process,(LPCVOID)(uintptr_t)at,data,n,&got)&&got==n;}
 template<class T>bool read(uint32_t at,T&v){return read(at,&v,sizeof(v));}
 static BOOL CALLBACK findWindow(HWND h,LPARAM p){auto*b=(Bridge*)p;DWORD id=0;GetWindowThreadProcessId(h,&id);wchar_t c[128];GetClassNameW(h,c,128);if(id==b->pid&&std::wstring(c)==L"vanBascoPlayerClass"){b->mainWindow=h;return FALSE;}return TRUE;}
public:
 std::wstring status=L"Abra o player para começar";
 ~Bridge(){close();}
 void close(){if(process)CloseHandle(process);process=nullptr;pid=0;mainWindow=nullptr;}
 bool connected()const{return process!=nullptr;}
 HWND window(){if(!mainWindow||!IsWindow(mainWindow))EnumWindows(findWindow,(LPARAM)this);return mainWindow;}
 bool connect(){
  close();HANDLE all=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);if(all==INVALID_HANDLE_VALUE)return false;
  PROCESSENTRY32W e{};e.dwSize=sizeof(e);
  if(Process32FirstW(all,&e))do{
   if(_wcsicmp(e.szExeFile,L"vmidi.exe"))continue;
   HANDLE h=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION|PROCESS_VM_READ,FALSE,e.th32ProcessID);if(!h){status=L"Feche e abra os dois programas normalmente, sem administrador";continue;}
   wchar_t p[32768];DWORD len=32768;bool path=QueryFullProcessImageNameW(h,0,p,&len);
   if(!path||_wcsicmp(p,(folder()+L"vmidi.exe").c_str())){status=L"Feche o outro vanBasco e abra o desta pasta";CloseHandle(h);continue;}
   if(sha256(p)!="6bca5342b3f394f5c44fe458d4b697d1e4a63ac4998888bca7a073678edaf5ba"){status=L"Esta versão do player não é compatível com o painel";CloseHandle(h);break;}
   bool engine=false;HANDLE mods=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE|TH32CS_SNAPMODULE32,e.th32ProcessID);
   MODULEENTRY32W m{};m.dwSize=sizeof(m);
   if(mods!=INVALID_HANDLE_VALUE){if(Module32FirstW(mods,&m))do{
    if(!_wcsicmp(m.szModule,L"midi32.dll"))engine=sha256(m.szExePath)=="0407551698366ddd714734239c094ee3fb5a4583fa03db4d891b49401b503ffb";
   }while(Module32NextW(mods,&m));CloseHandle(mods);}
   if(!engine){status=L"Aguardando o motor MIDI compatível";CloseHandle(h);continue;}
   process=h;pid=e.th32ProcessID;EnumWindows(findWindow,(LPARAM)this);status=L"Conectado ao vanBasco";break;
  }while(Process32NextW(all,&e));CloseHandle(all);return process!=nullptr;
 }
 bool poll(Snapshot&out,int channel=-1){
  if(!process)return false;DWORD code=0;
  if(!GetExitCodeProcess(process,&code)||code!=STILL_ACTIVE){close();status=L"Player fechado • clique em Player para abrir";return false;}
  // This adapter is restricted by SHA-256 to the supplied 2001 binary.
  // This MIDI adapter is read-only. The separate UI extension themes Windows
  // controls and adds a toggle; it never changes this filter or its playback.
  uint32_t app=0,filter=0,player=0,check=0;
  if(!read(0x44b944,app)||!read(app+0xe8,filter)||!read(app+0xe0,player))return false;
  std::array<BYTE,0x12a4> data{};uint32_t playing=0;
  if(!read(filter,data.data(),data.size())||!read(player+0x50,playing)||!read(app+0xe8,check)||check!=filter)return false;
  Snapshot s;s.playing=playing!=0;s.playerId=player;
  // Native playback uses musical ticks at +0x18, independent of tempo/speed.
  read(player+0x18,s.tick);read(player+0x14,s.division);
  // Current song descriptor is copied at app+0xa54; its path is CString +8.
  uint32_t str=0;int length=0;
  if(read(app+0xa5c,str)&&read(str-8,length)&&length>0&&length<32768){
   std::string path(length,'\0');if(read(str,&path[0],path.size())){
    int n=MultiByteToWideChar(CP_ACP,0,path.data(),length,nullptr,0);if(n>0){s.file.resize(n);MultiByteToWideChar(CP_ACP,0,path.data(),length,&s.file[0],n);}
   }
  }
  s.muted=data[0x1290]|(data[0x1291]<<8);s.drums=data[0x1294]|(data[0x1295]<<8);
  s.transpose=(short)(data[0x129e]|(data[0x129f]<<8));
  if(s.transpose<-48||s.transpose>48)return false;
  for(int ch=0;ch<16;++ch){
   if((s.drums&(1u<<ch))||(s.muted&(1u<<ch)))continue;
   for(int n=0;n<128;++n){
    // Four independent 2-bit view states; the high pair is not consumed
    // by the native piano/output windows. Bit 7 is held between on/off.
    if(data[ch*128+n]&0x80){double velocity=0.4+data[0x800+ch*128+n]/127.0;s.channels[ch][n]=velocity;if(channel<0||ch==channel)s.notes[n]=std::max(s.notes[n],velocity);}
   }
  }
  if(!read(app+0xe0,check)||check!=player)return false;
  out=s;status=s.playing?L"Ao vivo • notas do player":L"Player parado ou pausado";return true;
 }
};
