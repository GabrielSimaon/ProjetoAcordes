#pragma once
#include <windows.h>
inline UINT themeMessage(){static UINT id=RegisterWindowMessageW(L"VanBascoAcordes.Visual2.Attach");return id;}
inline UINT toggleMessage(){static UINT id=RegisterWindowMessageW(L"VanBascoAcordes.Visual2.Toggle");return id;}
constexpr const wchar_t* toggleProperty=L"VanBascoAcordes.Toggle";
