#include "chord_stream.h"
#include <cassert>
#include <iostream>
using namespace music;
Notes notes(std::initializer_list<int> list){Notes a{};for(int n:list)a[n]=1;return a;}
int main(){
 ChordStream s;unsigned t=0;
 auto c=notes({48,60,64,67}),am=notes({45,60,64,69}),g=notes({43,59,62,67}),dm=notes({50,62,65,69});
 auto feed=[&](Notes n,int ms){for(int i=0;i<ms;i+=40){t+=40;s.update(t,n);}};
 feed(c,240);assert(name(s.value())==L"C");
 feed(am,240);assert(name(s.value())==L"Am");
 feed(g,240);assert(name(s.value())==L"G");
 feed(dm,240);assert(name(s.value())==L"Dm"); // no mandatory 1.1 second lock
 feed(c,80);assert(name(s.value())==L"Dm");feed(dm,120);assert(name(s.value())==L"Dm");
 feed({},600);assert(name(s.value())==L"Dm");feed({},1400);assert(!s.value().valid());
 s.reset();for(int i=0;i<8;++i){feed(notes({60}),160);feed(notes({64}),160);feed(notes({67}),160);}assert(!s.value().valid());
 assert(!detect(notes({48,60,63,64,67}),{},true).valid()); // contradictory thirds: no invented major/minor
 s.settings(true,false);feed(notes({45,57,60,64,67}),240);assert(name(s.value())==L"Am");
 s.settings(false,false);feed(notes({45,57,60,64,67}),240);assert(name(s.value())==L"Am7");
 s.settings(true,true);feed(c,240);assert(!s.value().valid());feed(c,160);assert(name(s.value())==L"C");
 s.reset();t=0xffffff90;feed(c,400);assert(name(s.value())==L"C");
 for(int r=0;r<12;++r)for(int kind=0;kind<16;++kind){Chord original{r,kind,(r+4)%12,1};auto basic=simplify(original);assert(basic.root==r&&basic.bass==r);if(kind==1||kind==3||kind==12||kind==15)assert(basic.kind==1);
  for(int shift=-12;shift<=12;++shift){auto v=transposed(original,shift);assert(v.root==(r+shift+12)%12&&v.kind==kind&&v.bass==(original.bass+shift+12)%12);}}
 std::array<Notes,16> channels{};channels[0]=notes({72});channels[2]=am;channels[5]=notes({40});
 s.settings(true,false);t=0;for(int i=0;i<10;++i){t+=40;s.updateChannels(t,channels);}assert(name(s.value())==L"Am"&&s.source()==2);
 // A melody note above the accompaniment cannot invent a ninth/major chord.
 channels[0]=notes({74});channels[2]=dm;for(int i=0;i<6;++i){t+=40;s.updateChannels(t,channels);}assert(name(s.value())==L"Dm"&&s.source()==2);
 channels[0]=c;for(int i=0;i<12;++i){t+=40;s.updateChannels(t,channels);}assert(s.source()==2);
 s.reset();for(int i=0;i<8;++i){t+=40;s.updateChannels(t,channels,0);}assert(name(s.value())==L"C"&&s.source()==0);
 s.reset();channels={};channels[0]=notes({60});channels[1]=notes({64});channels[2]=notes({67});for(int i=0;i<20;++i){t+=40;s.updateChannels(t,channels);}assert(!s.value().valid());
 std::cout<<"PASS: minor/major, short real chord changes, passing notes, uncertain thirds, no melodic pooling, gaps, channel isolation, 4800 transpositions\n";
}
