#pragma once
// Legacy-safe subclassing: only USER32 entry points, on the owning UI thread.
#ifndef WINDOW_STYLE_TEST
#include <windows.h>
#endif
#include <new>
namespace window_style {
constexpr const wchar_t* property=L"VanBascoAcordes.WindowStyle12";
struct State {WNDPROC original;bool unicode;DWORD_PTR role;};
inline State* get(HWND h){return (State*)GetPropW(h,property);}
inline LRESULT forward(const State& s,HWND h,UINT m,WPARAM w,LPARAM l){
 return s.unicode?CallWindowProcW(s.original,h,m,w,l):CallWindowProcA(s.original,h,m,w,l);
}
inline bool install(HWND h,WNDPROC proc,DWORD_PTR role){
 if(GetWindowThreadProcessId(h,nullptr)!=GetCurrentThreadId())return false;
 if(get(h))return true;
 bool unicode=IsWindowUnicode(h)!=FALSE;
 auto old=(WNDPROC)(unicode?GetWindowLongPtrW(h,GWLP_WNDPROC):GetWindowLongPtrA(h,GWLP_WNDPROC));
 if(!old)return false;
 auto*s=new(std::nothrow) State{old,unicode,role};if(!s)return false;
 if(!SetPropW(h,property,(HANDLE)s)){delete s;return false;}
 SetLastError(0);
 LONG_PTR prev=unicode?SetWindowLongPtrW(h,GWLP_WNDPROC,(LONG_PTR)proc):SetWindowLongPtrA(h,GWLP_WNDPROC,(LONG_PTR)proc);
 if(!prev&&GetLastError()){RemovePropW(h,property);delete s;return false;}
 if(prev)s->original=(WNDPROC)prev;
 return true;
}
inline LRESULT destroy(HWND h,WNDPROC ours,UINT m,WPARAM w,LPARAM l){
 State*s=get(h);if(!s)return 0;
 LRESULT result=forward(*s,h,m,w,l);
 auto proc=(WNDPROC)(s->unicode?GetWindowLongPtrW(h,GWLP_WNDPROC):GetWindowLongPtrA(h,GWLP_WNDPROC));
 // Leave a later subclass in place if another extension owns the outer layer.
 if(proc==ours){if(s->unicode)SetWindowLongPtrW(h,GWLP_WNDPROC,(LONG_PTR)s->original);else SetWindowLongPtrA(h,GWLP_WNDPROC,(LONG_PTR)s->original);}
 RemovePropW(h,property);delete s;return result;
}
}
