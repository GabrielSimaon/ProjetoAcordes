"""Check actual vanBasco transpose handlers in CPU emulation, never patch disk files."""
from test_native_filter import *
exe=dll.parent/'vmidi.exe'
p=pefile.PE(str(exe)); eb=p.OPTIONAL_HEADER.ImageBase
im=p.get_memory_mapped_image();u.mem_map(eb,(len(im)+4095)&~4095);u.mem_write(eb,im)
app=0x21000000;u.mem_map(app,4096);u.mem_write(app+0xe8,struct.pack('<I',obj))
# Stub only the loaded-file predicate in emulator memory.
u.mem_write(0x403c9b,b'\x31\xc0\xc3')
u.mem_write(0x44b8e8,struct.pack('<I',base+0x1ee8))
u.mem_write(0x44b870,struct.pack('<I',base+0x1eda))
# Verify WM_COMMAND IDs in the real MFC message map.
for command,handler in [(0x8014,0x40e316),(0x8015,0x40e2e1)]:
 assert struct.pack('<6I',0x111,0,command,command,0xc,handler) in exe.read_bytes()
call(base+0x1123,this=obj)
short(0x129e,0)
def transpose():return struct.unpack('<h',struct.pack('<H',call(base+0x1ee8,obj)&0xffff))[0]
for i in range(15):
 call(0x40e316,this=app)
 assert transpose()==min(i+1,12)
for i in range(27):
 call(0x40e2e1,this=app)
 assert transpose()==max(11-i,-12)
for i in range(12):call(0x40e316,this=app)
assert transpose()==0
call(0x40e316,this=app);call(0x40e316,this=app)
for n in (57,60,64):emit(0x90,n,100)
assert active()==[59,62,66] # Am -> Bm, transposed exactly once
print('Native transpose passed: command map, both handlers, +/-12 bounds, reset and Am -> Bm.')
