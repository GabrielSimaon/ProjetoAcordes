#pragma once
#include <cstdint>

class PlayerLifetime {
 bool seen_=false;
 bool waiting_=false;
 uint32_t disconnectedAt_=0;
public:
 bool update(uint32_t now,bool connected,uint32_t grace=1000){
  if(connected){seen_=true;waiting_=false;return false;}
  if(!seen_)return false;
  if(!waiting_){waiting_=true;disconnectedAt_=now;return false;}
  return uint32_t(now-disconnectedAt_)>=grace;
 }
};
