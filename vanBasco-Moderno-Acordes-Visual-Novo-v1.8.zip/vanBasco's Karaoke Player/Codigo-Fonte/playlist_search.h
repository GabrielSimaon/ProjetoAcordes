#pragma once
#include <string>
namespace playlist_search {
inline std::wstring fold(std::wstring s){
 const std::wstring accents=L"áàãâäÁÀÃÂÄéèêëÉÈÊËíìîïÍÌÎÏóòôõöÓÒÔÕÖúùûüÚÙÛÜçÇ";
 const std::wstring plain=L"aaaaaaaaaaeeeeeeeeiiiiiiiioooooooooouuuuuuuucc";
 for(auto&c:s){auto p=accents.find(c);if(p!=std::wstring::npos)c=plain[p];else if(c>=L'A'&&c<=L'Z')c+=L'a'-L'A';}return s;
}
inline bool matches(const std::wstring& text,const std::wstring& query){return fold(text).find(fold(query))!=std::wstring::npos;}
}
