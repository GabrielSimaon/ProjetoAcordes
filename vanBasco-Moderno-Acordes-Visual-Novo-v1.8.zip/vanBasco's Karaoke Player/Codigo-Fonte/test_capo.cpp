#include "capo.h"
#include <cassert>
#include <iostream>
using namespace music;

int main(){
 std::vector<WeightedChord> bbSong={{{10,0,10,1},4},{{3,0,3,1},2},{{5,0,5,1},2}};
 auto bb=suggestCapo(bbSong);
 assert(bb.useful&&bb.fret==1); // Bb/Eb/F becomes A/D/E.
 assert(transposed(bbSong[0].chord,-bb.fret).root==9);

 std::vector<WeightedChord> easy={{{0,0,0,1},4},{{9,1,9,1},2},{{5,0,5,1},2},{{7,0,7,1},2}};
 auto c=suggestCapo(easy);
 assert(!c.useful&&c.fret==0);

 std::vector<WeightedChord> sharpSong={{{1,0,1,1},4},{{6,0,6,1},2},{{8,0,8,1},2}};
 auto sharp=suggestCapo(sharpSong);
 assert(sharp.useful&&sharp.fret>=1&&sharp.fret<=7);
 std::cout<<"capo tests ok\n";
}
