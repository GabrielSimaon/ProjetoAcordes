// Visual-only extension, installed on the verified player's UI thread.
// Original MIDI functions, window commands, controls and list data are untouched.
#define UNICODE
#define _UNICODE
#define NOMINMAX
#include <windows.h>
#include <commctrl.h>
#include <uxtheme.h>
#include <shellapi.h>
#include <string>
#include <algorithm>
#include "theme_protocol.h"
#include "window_style.h"
#include "playlist_ui.h"
namespace {
HINSTANCE module;HWND controller,mainPlayer,toggle;HFONT font;HBRUSH backBrush,panelBrush;
constexpr COLORREF bg=RGB(14,19,26),surface=RGB(23,31,41),ink=RGB(236,243,247),mint=RGB(106,237,197),muted=RGB(144,161,179);
bool initialized=false;
std::wstring klass(HWND h){wchar_t s[128]{};GetClassNameW(h,s,128);return s;}
void darkCaption(HWND h){
 HMODULE dwm=LoadLibraryW(L"dwmapi.dll");if(!dwm)return;
 using Fn=HRESULT(WINAPI*)(HWND,DWORD,LPCVOID,DWORD);auto f=(Fn)GetProcAddress(dwm,"DwmSetWindowAttribute");
 if(f){BOOL yes=TRUE;f(h,20,&yes,sizeof yes);f(h,35,&surface,sizeof surface);f(h,36,&ink,sizeof ink);}FreeLibrary(dwm);
}
void reopen(){
 if(IsWindow(controller)&&klass(controller)==L"VanBascoAcordesWindow"){DWORD pid=0;GetWindowThreadProcessId(controller,&pid);AllowSetForegroundWindow(pid);PostMessageW(controller,toggleMessage(),0,0);return;}
 wchar_t path[32768];GetModuleFileNameW(module,path,32768);std::wstring dir=path;dir.resize(dir.find_last_of(L"\\/")+1);
 ShellExecuteW(mainPlayer,L"open",(dir+L"Acordes.exe").c_str(),nullptr,dir.c_str(),SW_SHOWNORMAL);
}
LRESULT CALLBACK toggleProc(HWND h,UINT m,WPARAM w,LPARAM l){
 switch(m){
 case WM_PAINT:{PAINTSTRUCT ps;HDC dc=BeginPaint(h,&ps);RECT r;GetClientRect(h,&r);FillRect(dc,&r,panelBrush);bool on=IsWindow(controller)&&IsWindowVisible(controller);HBRUSH b=CreateSolidBrush(on?mint:RGB(43,55,69));HPEN p=CreatePen(PS_SOLID,1,on?mint:muted);auto ob=SelectObject(dc,b);auto op=SelectObject(dc,p);RoundRect(dc,1,1,r.right-1,r.bottom-1,8,8);SetBkMode(dc,TRANSPARENT);SetTextColor(dc,on?bg:ink);auto of=SelectObject(dc,font);DrawTextW(dc,L"Acordes",-1,&r,DT_CENTER|DT_VCENTER|DT_SINGLELINE);SelectObject(dc,of);SelectObject(dc,ob);SelectObject(dc,op);DeleteObject(b);DeleteObject(p);if(GetFocus()==h){InflateRect(&r,-4,-4);DrawFocusRect(dc,&r);}EndPaint(h,&ps);return 0;}
 case WM_LBUTTONDOWN:SetCapture(h);SetFocus(h);return 0;
 case WM_LBUTTONUP:{bool captured=GetCapture()==h;ReleaseCapture();RECT r;GetClientRect(h,&r);POINT p{(short)LOWORD(l),(short)HIWORD(l)};if(captured&&PtInRect(&r,p))reopen();return 0;}
 case WM_KEYUP:if(w==VK_SPACE||w==VK_RETURN){reopen();return 0;}break;
 case WM_SETFOCUS:case WM_KILLFOCUS:InvalidateRect(h,nullptr,FALSE);return 0;
 case WM_ERASEBKGND:return 1;
 }
 return DefWindowProcW(h,m,w,l);
}
void placeToggle(){if(!IsWindow(toggle))return;RECT r;GetClientRect(mainPlayer,&r);ShowWindow(toggle,r.right>=370?SW_SHOWNOACTIVATE:SW_HIDE);SetWindowPos(toggle,HWND_TOP,205,3,94,23,SWP_NOACTIVATE);InvalidateRect(toggle,nullptr,FALSE);}
// Recolor only the native playlist's custom-painted chrome. Child controls
// retain their own painting, hit targets, keyboard handling and scrollbars.
void recolorChrome(HWND h){
 RECT r{};if(!GetClientRect(h,&r))return;int width=r.right,height=r.bottom;if(width<=0||height<=0||width>4096||height>4096)return;
 HDC dc=GetDC(h),mem=CreateCompatibleDC(dc);BITMAPINFO info{};info.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);info.bmiHeader.biWidth=width;info.bmiHeader.biHeight=-height;info.bmiHeader.biPlanes=1;info.bmiHeader.biBitCount=32;info.bmiHeader.biCompression=BI_RGB;
 DWORD* pixels=nullptr;HBITMAP bm=CreateDIBSection(dc,&info,DIB_RGB_COLORS,(void**)&pixels,nullptr,0);
 if(!bm){DeleteDC(mem);ReleaseDC(h,dc);return;}auto old=SelectObject(mem,bm);BitBlt(mem,0,0,width,height,dc,0,0,SRCCOPY);GdiFlush();
 for(int i=0;i<width*height;++i){DWORD c=pixels[i];int b=c&255,g=(c>>8)&255,red=(c>>16)&255;int high=std::max({red,g,b}),low=std::min({red,g,b});if(high-low>8)continue;
  COLORREF out=high<45?ink:high<150?muted:high<225?surface:bg;pixels[i]=RGB(GetBValue(out),GetGValue(out),GetRValue(out));}
 int state=SaveDC(dc);
 for(HWND child=GetWindow(h,GW_CHILD);child;child=GetWindow(child,GW_HWNDNEXT))if(IsWindowVisible(child)){RECT cr;GetWindowRect(child,&cr);MapWindowPoints(nullptr,h,(POINT*)&cr,2);ExcludeClipRect(dc,cr.left,cr.top,cr.right,cr.bottom);}
 BitBlt(dc,0,0,width,height,mem,0,0,SRCCOPY);RestoreDC(dc,state);SelectObject(mem,old);DeleteObject(bm);DeleteDC(mem);ReleaseDC(h,dc);
}
LRESULT customDraw(NMHDR* hdr,LRESULT original){
 if(hdr->code==TTN_GETDISPINFOW){auto*t=(NMTTDISPINFOW*)hdr;if(t->lpszText&&!IS_INTRESOURCE(t->lpszText)){auto localized=playlist_ui::translated(t->lpszText);if(localized!=t->lpszText){lstrcpynW(t->szText,localized.c_str(),80);t->lpszText=t->szText;}}return original;}
 if(hdr->code==TTN_GETDISPINFOA){auto*t=(NMTTDISPINFOA*)hdr;if(t->lpszText&&!IS_INTRESOURCE(t->lpszText)){wchar_t wide[512]{};MultiByteToWideChar(CP_ACP,0,t->lpszText,-1,wide,512);auto localized=playlist_ui::translated(wide);if(localized!=wide){WideCharToMultiByte(CP_ACP,0,localized.c_str(),-1,t->szText,80,nullptr,nullptr);t->lpszText=t->szText;}}return original;}
 if(hdr->code!=NM_CUSTOMDRAW)return original;
 auto*c=(NMCUSTOMDRAW*)hdr;auto cl=klass(hdr->hwndFrom);
 if(cl==WC_LISTVIEWW){
  if(c->dwDrawStage==CDDS_PREPAINT)return original|CDRF_NOTIFYITEMDRAW;
  if(c->dwDrawStage==CDDS_ITEMPREPAINT){auto*lv=(NMLVCUSTOMDRAW*)c;if(lv->clrText==CLR_DEFAULT||lv->clrText==GetSysColor(COLOR_WINDOWTEXT)||lv->clrText==ink)lv->clrText=ink;if(lv->clrTextBk==CLR_DEFAULT||lv->clrTextBk==GetSysColor(COLOR_WINDOW)||lv->clrTextBk==bg||lv->clrTextBk==surface)lv->clrTextBk=(c->dwItemSpec%2)?surface:bg;return original;}
 }
 if(cl==WC_HEADERW){
  if(c->dwDrawStage==CDDS_PREPAINT)return CDRF_NOTIFYITEMDRAW;
  if(c->dwDrawStage==CDDS_ITEMPREPAINT){RECT r=c->rc;FillRect(c->hdc,&r,panelBrush);wchar_t label[512]{};HDITEMW item{};item.mask=HDI_TEXT|HDI_FORMAT;item.pszText=label;item.cchTextMax=512;SendMessageW(hdr->hwndFrom,HDM_GETITEMW,c->dwItemSpec,(LPARAM)&item);r.left+=10;r.right-=6;SetBkMode(c->hdc,TRANSPARENT);SetTextColor(c->hdc,mint);auto old=SelectObject(c->hdc,font);auto localized=playlist_ui::translated(label);DrawTextW(c->hdc,localized.c_str(),-1,&r,DT_SINGLELINE|DT_VCENTER|DT_END_ELLIPSIS);SelectObject(c->hdc,old);return CDRF_SKIPDEFAULT;}
 }
 return original;
}
LRESULT CALLBACK styled(HWND h,UINT m,WPARAM w,LPARAM l){
 auto* state=window_style::get(h);
 if(!state)return IsWindowUnicode(h)?DefWindowProcW(h,m,w,l):DefWindowProcA(h,m,w,l);
 if(m==WM_NCDESTROY){if(state->role==2){playlist_ui::restore(h);playlist_ui::destroy(h);}return window_style::destroy(h,styled,m,w,l);}
 DWORD_PTR role=state->role;
 if(role==2){
  if(m==WM_COMMAND&&playlist_ui::command(h,w))return 0;
  if(m==WM_CTLCOLORSTATIC&&playlist_ui::ours((HWND)l)){SetTextColor((HDC)w,LOWORD(GetDlgCtrlID((HWND)l))==playlist_ui::titleId?ink:muted);SetBkMode((HDC)w,TRANSPARENT);return (LRESULT)backBrush;}
  if(m==WM_ERASEBKGND){RECT r;GetClientRect(h,&r);FillRect((HDC)w,&r,backBrush);return 1;}
  if(m==WM_DRAWITEM&&playlist_ui::draw((DRAWITEMSTRUCT*)l,font))return TRUE;
  if(m==WM_INITMENUPOPUP){LRESULT r=window_style::forward(*state,h,m,w,l);playlist_ui::menu((HMENU)w);return r;}
  if(m==WM_SIZE){auto*p=playlist_ui::get(h);if(p&&p->arranging)return window_style::forward(*state,h,m,w,l);playlist_ui::restore(h);LRESULT r=window_style::forward(*state,h,m,w,l);playlist_ui::place(h);return r;}
 }

 if(role==3&&m==WM_KEYDOWN&&w=='F'&&(GetKeyState(VK_CONTROL)&0x8000)){HWND parent=GetParent(h);for(int i=0;i<4&&parent;++i,parent=GetParent(parent))if(auto*p=playlist_ui::get(parent)){SetFocus(p->edit);return 0;}}
 if(role==1){ // main player: add a child toggle, forward every native message.
  LRESULT result=window_style::forward(*state,h,m,w,l);if(m==WM_SIZE||m==WM_SHOWWINDOW)placeToggle();return result;
 }
 if(m==WM_CTLCOLORLISTBOX||m==WM_CTLCOLOREDIT||m==WM_CTLCOLORSTATIC||m==WM_CTLCOLORBTN){HDC dc=(HDC)w;SetTextColor(dc,ink);SetBkColor(dc,surface);return (LRESULT)panelBrush;}
 if(m==WM_NOTIFY){LRESULT result=window_style::forward(*state,h,m,w,l);return customDraw((NMHDR*)l,result);}
 if(role==2&&m==WM_PAINT){LRESULT result=window_style::forward(*state,h,m,w,l);recolorChrome(h);return result;}
 return window_style::forward(*state,h,m,w,l);
}
BOOL CALLBACK styleChild(HWND h,LPARAM){
 if(GetWindowThreadProcessId(h,nullptr)!=GetCurrentThreadId())return TRUE;
 if(window_style::get(h)||(GetDlgCtrlID(h)>=playlist_ui::editId&&GetDlgCtrlID(h)<=playlist_ui::subtitleId))return TRUE;
 if(!window_style::install(h,styled,3))return TRUE;auto cl=klass(h);
 if(cl==WC_LISTVIEWW){SetWindowTheme(h,L"Explorer",nullptr);SendMessageW(h,WM_SETFONT,(WPARAM)font,TRUE);ListView_SetBkColor(h,bg);ListView_SetTextBkColor(h,bg);ListView_SetTextColor(h,ink);ListView_SetExtendedListViewStyleEx(h,LVS_EX_DOUBLEBUFFER,LVS_EX_DOUBLEBUFFER);}
 else if(cl==L"ComboBox"||cl==L"Edit"||cl==L"Static"||cl==WC_HEADERW){SendMessageW(h,WM_SETFONT,(WPARAM)font,TRUE);}
 InvalidateRect(h,nullptr,TRUE);return TRUE;
}
BOOL CALLBACK scanWindow(HWND h,LPARAM){
 DWORD pid=0;DWORD thread=GetWindowThreadProcessId(h,&pid);if(pid!=GetCurrentProcessId()||thread!=GetCurrentThreadId())return TRUE;
 // Native playlist has these two list-view IDs (verified in supplied binary).
 HWND list=GetDlgItem(h,0x1001);bool playlist=list&&klass(list)==WC_LISTVIEWW&&GetDlgItem(h,0x1003);
 wchar_t title[256]{};GetWindowTextW(h,title,256);bool karaoke=std::wstring(title).find(L" - Karaoke")!=std::wstring::npos;
 if(playlist){if(!window_style::get(h)){if(!window_style::install(h,styled,2))return TRUE;darkCaption(h);InvalidateRect(h,nullptr,TRUE);}EnumChildWindows(h,styleChild,0);playlist_ui::attach(h,font,module);}
 if(karaoke&&!GetPropW(h,L"VanBascoAcordes.Caption")){darkCaption(h);SetPropW(h,L"VanBascoAcordes.Caption",(HANDLE)1);}
 return TRUE;
}
void attach(HWND target,HWND panel){
 controller=panel;mainPlayer=target;
 if(!initialized){
  // Subclasses must outlive the hook and the external panel. Pin this module
  // until the native process exits; no dangling callback after Unhook.
  HMODULE keep;GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_PIN,(LPCWSTR)&attach,&keep);
  font=CreateFontW(-13,0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,L"Segoe UI");
  backBrush=CreateSolidBrush(bg);panelBrush=CreateSolidBrush(surface);
  WNDCLASSW wc{};wc.lpfnWndProc=toggleProc;wc.hInstance=module;wc.lpszClassName=L"VanBascoAcordesNativeToggle";wc.hCursor=LoadCursor(nullptr,IDC_HAND);RegisterClassW(&wc);initialized=true;
 }
 if(!IsWindow(toggle)){
  if(!window_style::install(target,styled,1))return;
  toggle=CreateWindowExW(0,L"VanBascoAcordesNativeToggle",L"Acordes",WS_CHILD|WS_VISIBLE|WS_TABSTOP,205,3,94,23,target,nullptr,module,nullptr);
  SetPropW(target,toggleProperty,toggle);placeToggle();
 }
 InvalidateRect(toggle,nullptr,FALSE);EnumThreadWindows(GetCurrentThreadId(),scanWindow,0);
}
}
extern "C" __declspec(dllexport) LRESULT CALLBACK ThemeHook(int code,WPARAM w,LPARAM l){
 if(code>=0){auto*c=(CWPSTRUCT*)l;if(c->message==themeMessage()&&klass(c->hwnd)==L"vanBascoPlayerClass")attach(c->hwnd,(HWND)c->wParam);}
 return CallNextHookEx(nullptr,code,w,l);
}
BOOL WINAPI DllMain(HINSTANCE h,DWORD reason,LPVOID){if(reason==DLL_PROCESS_ATTACH){module=h;}return TRUE;}
