// Portable regression test: model USER32 to test ANSI/Unicode forwarding,
// install failures, thread restrictions and teardown without Windows GUI.
#define WINDOW_STYLE_TEST
#include <cstdint>
#include <cassert>
#include <iostream>
using UINT=unsigned;using DWORD=unsigned;using WPARAM=uintptr_t;using LPARAM=intptr_t;using LRESULT=intptr_t;using LONG_PTR=intptr_t;using DWORD_PTR=uintptr_t;using HANDLE=void*;
struct Window;using HWND=Window*;using WNDPROC=LRESULT(*)(HWND,UINT,WPARAM,LPARAM);
struct Window{WNDPROC proc;HANDLE property=nullptr;bool unicode=false;DWORD thread=1;bool failProp=false,failSet=false;int ansi=0,wide=0;};
constexpr int FALSE=0,GWLP_WNDPROC=-4;DWORD error=0;
HANDLE GetPropW(HWND h,const wchar_t*){return h->property;}
bool SetPropW(HWND h,const wchar_t*,HANDLE p){if(h->failProp)return false;h->property=p;return true;}
HANDLE RemovePropW(HWND h,const wchar_t*){auto p=h->property;h->property=nullptr;return p;}
DWORD GetWindowThreadProcessId(HWND h,void*){return h->thread;}DWORD GetCurrentThreadId(){return 1;}
bool IsWindowUnicode(HWND h){return h->unicode;}void SetLastError(DWORD e){error=e;}DWORD GetLastError(){return error;}
LONG_PTR GetWindowLongPtrW(HWND h,int){return (LONG_PTR)h->proc;}LONG_PTR GetWindowLongPtrA(HWND h,int){return (LONG_PTR)h->proc;}
LONG_PTR SetWindowLongPtrW(HWND h,int,LONG_PTR p){if(h->failSet){error=5;return 0;}auto old=h->proc;h->proc=(WNDPROC)p;++h->wide;return (LONG_PTR)old;}
LONG_PTR SetWindowLongPtrA(HWND h,int,LONG_PTR p){if(h->failSet){error=5;return 0;}auto old=h->proc;h->proc=(WNDPROC)p;++h->ansi;return (LONG_PTR)old;}
LRESULT CallWindowProcW(WNDPROC p,HWND h,UINT m,WPARAM w,LPARAM l){++h->wide;return p(h,m,w,l);}
LRESULT CallWindowProcA(WNDPROC p,HWND h,UINT m,WPARAM w,LPARAM l){++h->ansi;return p(h,m,w,l);}
#include "window_style.h"
LRESULT original(HWND,UINT m,WPARAM w,LPARAM l){return m+w+l;}
LRESULT wrapper(HWND h,UINT m,WPARAM w,LPARAM l){return window_style::forward(*window_style::get(h),h,m,w,l);}
LRESULT other(HWND,UINT,WPARAM,LPARAM){return 0;}
int main(){
 for(bool wide:{false,true}){Window h{original};h.unicode=wide;
  assert(window_style::install(&h,wrapper,7));assert(window_style::get(&h)->role==7);
  assert(h.proc(&h,20,30,40)==90);assert(wide?h.ansi==0:h.wide==0);
  assert(window_style::install(&h,wrapper,7));assert(window_style::get(&h)->original==original);
  assert(window_style::destroy(&h,wrapper,5,6,7)==18);assert(h.proc==original&&!h.property);
 }
 Window h{original};h.failProp=true;assert(!window_style::install(&h,wrapper,1));assert(h.proc==original&&!h.property);
 h.failProp=false;h.failSet=true;assert(!window_style::install(&h,wrapper,1));assert(h.proc==original&&!h.property);
 h.failSet=false;h.thread=2;assert(!window_style::install(&h,wrapper,1));h.thread=1;
 assert(window_style::install(&h,wrapper,1));h.proc=other;window_style::destroy(&h,wrapper,1,2,3);assert(h.proc==other&&!h.property);
 std::cout<<"PASS: ANSI/Unicode native messages, install/restore, errors, owning thread, later subclass\n";
}
