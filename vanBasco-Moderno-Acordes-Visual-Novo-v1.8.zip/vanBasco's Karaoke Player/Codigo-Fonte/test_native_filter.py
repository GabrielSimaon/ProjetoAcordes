"""Execute the supplied MIDI filter's x86 code in an isolated CPU emulator.
This checks the read-only adapter's layout against the real DLL, without
running the Windows player or replacing any of its functions.
Requires: pip install unicorn pefile
"""
import struct
from pathlib import Path
import pefile
from unicorn import Uc, UC_ARCH_X86, UC_MODE_32
from unicorn.x86_const import UC_X86_REG_ESP, UC_X86_REG_ECX, UC_X86_REG_EAX

root=Path(__file__).resolve().parent.parent
dll=root/'work'/"vanBasco's Karaoke Player"/'midi32.dll'
if not dll.exists(): dll=root/'midi32.dll'
pe=pefile.PE(str(dll)); base=pe.OPTIONAL_HEADER.ImageBase
u=Uc(UC_ARCH_X86,UC_MODE_32)
image=pe.get_memory_mapped_image();u.mem_map(base,(len(image)+4095)&~4095);u.mem_write(base,image)
obj=0x20000000;stack=0x30000000;stop=0x40000000;buffer=obj+0x10000
u.mem_map(obj,0x20000);u.mem_map(stack,0x10000);u.mem_map(stop,4096)

def call(address,*args,this=None):
    sp=stack+0x8000
    u.mem_write(sp,struct.pack('<'+'I'*(len(args)+1),stop,*args))
    u.reg_write(UC_X86_REG_ESP,sp)
    if this is not None:u.reg_write(UC_X86_REG_ECX,this)
    u.emu_start(address,stop,count=300000)
    assert u.reg_read(UC_X86_REG_ESP)>=sp
    return u.reg_read(UC_X86_REG_EAX)

def emit(status,note,velocity=0):return call(base+0x1156,status|(note<<8)|(velocity<<16),this=obj)
def active(ch=0):return [n for n,v in enumerate(u.mem_read(obj+128*ch,128)) if v&128]
def short(offset,value):u.mem_write(obj+offset,struct.pack('<h',value))

call(base+0x103f,this=obj);call(base+0x1123,this=obj)
assert not active()
for note in (60,64,67):emit(0x90,note,100)
assert active()==[60,64,67]
# Calling the native piano/output accessors does not consume our view state.
for view in (0,1):call(base+0x1f0b,obj,0,view,buffer)
assert active()==[60,64,67]
emit(0x80,64);assert active()==[60,67]
emit(0x90,60,0);assert active()==[67]
emit(0x80,67);assert not active()
# Native transposition is applied before the display's key array is populated.
short(0x129e,2);emit(0x90,60,100);assert active()==[62]
emit(0x80,60);assert not active()
# Percussion is separately marked and does not transpose.
emit(0x99,60,100);assert active(9)==[60]
assert struct.unpack('<H',u.mem_read(obj+0x1294,2))[0]==512
# A muted channel must not add active notes.
short(0x1290,1);emit(0x90,60,100);assert not active()
short(0x1290,0);short(0x129e,-3);emit(0x91,60,90);assert active(1)==[57]
emit(0xb1,123,0);assert not active(1)
print('Native DLL passed: initialization, note-on/off, velocity-zero, native piano polling, positive/negative transpose, percussion, mute, all-notes-off.')
