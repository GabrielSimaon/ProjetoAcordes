#include "chords.h"
#include <cassert>
#include <iostream>
using namespace music;
int main(){
 int cases=0,shapes=0;int tuning[]={40,45,50,55,59,64};
 for(int r=0;r<12;++r)for(int k=0;k<(int)kinds().size();++k){
  Chord c{r,k,r,1};std::array<double,128> notes{};
  notes[36+r]=1;for(int i:kinds()[k].intervals)notes[60+r+i]=1;
  Chord result=detect(notes,c);
  if(!result.valid()||mask(c)!=mask(result)||result.root!=r){std::cerr<<"Detection failed "<<r<<" "<<k<<"\n";return 1;}
  auto s=shape(c);if(s.valid){unsigned got=0;for(int i=0;i<6;++i)if(s.fret[i]>=0)got|=1u<<((tuning[i]+s.fret[i])%12);
   if((got&~mask(c)) || ((mask(c)&~got)&~(1u<<((r+7)%12)))){std::cerr<<"Shape notes failed "<<r<<" "<<k<<"\n";return 1;}
   for(int d=1;d<=4;++d){int a=6,b=-1,f=-1;
    for(int i=0;i<6;++i)if(s.finger[i]==d){if(f>=0)assert(f==s.fret[i]);f=s.fret[i];a=std::min(a,i);b=i;}
    for(int i=a;i<=b;++i)if(s.fret[i]>=0)assert(s.fret[i]>=f);
   }++shapes;
  }++cases;
 }
 std::array<double,128> n{};assert(!detect(n).valid());n[60]=1;assert(!detect(n).valid());n[64]=1;assert(!detect(n).valid());n[67]=1;assert(detect(n).root==0);
 n={};n[40]=1;n[48]=1;n[55]=1;n[60]=1;n[64]=1;assert(detect(n).root==0&&detect(n).bass==4);
 n={};for(int p:{60,62,64,65,67,69,71})n[p]=1;assert(!detect(n).valid());
 std::cout<<cases<<" complete chord cases, "<<shapes<<" validated guitar shapes; silence, sparse notes, inversion and ambiguous scale passed.\n";
}
