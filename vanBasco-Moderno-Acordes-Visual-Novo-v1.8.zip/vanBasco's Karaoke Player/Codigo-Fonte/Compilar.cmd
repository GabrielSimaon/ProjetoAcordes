@echo off
call "%~dp0BUILD.cmd"
exit /b %errorlevel%
