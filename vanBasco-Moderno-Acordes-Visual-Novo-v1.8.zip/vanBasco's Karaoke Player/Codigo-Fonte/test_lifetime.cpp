#include "player_lifetime.h"
#include <cassert>
#include <cstdint>
#include <iostream>

int main(){
 PlayerLifetime life;
 assert(!life.update(0,false));
 assert(!life.update(5000,false));
 assert(!life.update(6000,true));
 assert(!life.update(6100,false));
 assert(!life.update(7099,false));
 assert(life.update(7100,false));
 assert(!life.update(7200,true));
 assert(!life.update(7300,false));
 assert(!life.update(7399,true));
 assert(!life.update(7500,false));
 assert(!life.update(8499,false));
 assert(life.update(8500,false));
 PlayerLifetime wrap;
 assert(!wrap.update(0xfffffff0u,true));
 assert(!wrap.update(0xfffffff8u,false));
 assert(!wrap.update(0x000003dfu,false));
 assert(wrap.update(0x000003e0u,false));
 std::cout<<"PASS: player lifetime, reconnect and tick wrap\n";
}
