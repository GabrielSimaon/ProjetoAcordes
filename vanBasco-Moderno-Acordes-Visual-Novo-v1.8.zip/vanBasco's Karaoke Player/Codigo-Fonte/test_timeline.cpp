#include "midi_timeline.h"
#include "playlist_search.h"
#include <cassert>
#include <iostream>
#include <fstream>
using namespace music;
int main(int argc,char**argv){
 assert(playlist_search::matches(L"CANÇÃO DO CORAÇÃO.kar",L"cancao"));assert(playlist_search::matches(L"MÚSICA",L"musica"));assert(!playlist_search::matches(L"Salsa.mid",L"rock"));
 Timeline t;t.division=480;t.end=3840;
 for(int n:{60,64,67})t.notes.push_back({0,1920,0,n,100,0});
 for(int n:{57,60,64})t.notes.push_back({1920,3840,0,n,100,0});
 t.analyze();auto a=t.at(0);assert(a.first.root==0&&a.first.kind==0&&a.second.root==9&&a.second.kind==1);
 auto view=t.viewAt(0);assert(view.nextTick==1920&&!view.held);assert(countdownBeats(0,view.nextTick,t.division)==4);
 assert(countdownBeats(480,view.nextTick,t.division)==3);assert(countdownBeats(960,view.nextTick,t.division)==2);assert(countdownBeats(1440,view.nextTick,t.division)==1);
 assert(countdownBeats(1919,view.nextTick,t.division)==1);assert(countdownBeats(1920,view.nextTick,t.division)==0);
 view=t.viewAt(1920);assert(view.current.root==9&&view.nextTick==0);
 assert(t.at(1800).first.root==0);assert(t.at(1920).first.root==9);assert(t.at(3500).second.root==-1);assert(!t.at(3840).first.valid());
 t.analyze(513);assert(!t.at(0).first.valid());t.analyze(512,1);assert(!t.at(0).first.valid());
 // Harmony distributed across channels, plus a short passing melody tone.
 t.notes.clear();for(int i=0;i<3;++i)t.notes.push_back({0,1920,i,std::array<int,3>{60,64,67}[i],100,0});t.notes.push_back({0,40,5,66,80,81});t.end=1920;t.analyze();assert(t.at(0).first.root==0);
 // Broken chord across a beat; minor quality survives.
 t.notes={{0,160,2,57,100,24},{160,320,2,60,100,24},{320,480,2,64,100,24},{480,960,2,57,100,24}};t.end=960;t.analyze();assert(t.at(0).first.root==9&&t.at(0).first.kind==1);
 // Parser: note releases, running status, pedal and malformed input.
 std::vector<unsigned char>b={'M','T','h','d',0,0,0,6,0,0,0,1,1,0xe0,'M','T','r','k',0,0,0,28,0,0x90,60,100,0,64,100,0,67,100,0x83,0x60,0x80,60,0,0,64,0,0,67,0,0,0xff,0x2f,0};
 // Length is computed, so the test is not coupled to byte counting.
 b[21]=b.size()-22;assert(t.parse(b));assert(t.notes.size()==3&&t.notes[0].end==480);t.analyze();assert(t.at(0).first.root==0);
 auto valid=b;
 std::vector<unsigned char> track={0,0xb0,64,127,0,0x90,60,100,120,0x80,60,0,120,0xb0,64,0,0,0xff,0x2f,0};
 b.resize(22);b[21]=track.size();b.insert(b.end(),track.begin(),track.end());assert(t.parse(b));assert(t.notes.size()==1&&t.notes[0].end==240);
 std::vector<unsigned char> rmi={'R','I','F','F',0,0,0,0,'R','M','I','D','d','a','t','a',0,0,0,0};
 rmi[16]=valid.size();rmi.insert(rmi.end(),valid.begin(),valid.end());rmi[4]=rmi.size()-8;assert(t.parse(rmi));assert(t.notes.size()==3);
 b.pop_back();assert(!t.parse(b));
 for(int i=1;i<argc;++i){std::ifstream f(argv[i],std::ios::binary);std::vector<unsigned char> bytes((std::istreambuf_iterator<char>(f)),{});assert(t.parse(bytes));t.analyze();
 if(std::string(argv[i]).find("Teste-Acordes")!=std::string::npos){int roots[]={0,9,5,7,0,9,5,7};for(int j=0;j<8;++j){auto pair=t.at(j*1920);assert(pair.first.root==roots[j]);assert(pair.first.kind==(j%4==1?1:0));if(j<7)assert(pair.second.root==roots[j+1]);}assert(t.at(1919).first.root==0&&t.at(1920).first.root==9);}
 unsigned valid=0;for(auto&s:t.segments)valid+=s.chord.valid();std::cout<<argv[i]<<": "<<t.notes.size()<<" notes, "<<valid<<" chord segments\n";}
 std::cout<<"PASS: current/next, countdown, exact boundary, end, mute, manual channel, split harmony, arpeggio, parser and truncation\n";
}
