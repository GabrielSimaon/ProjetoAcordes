"""Validate the timeline clock against the supplied DLL's actual position getter."""
from test_native_filter import *
from unicorn import UC_HOOK_CODE
from unicorn.x86_const import UC_X86_REG_EIP
player=0x21000000;u.mem_map(player,4096);muldiv=0x50000000;u.mem_map(muldiv,4096)
u.mem_write(base+0xc090,struct.pack('<I',muldiv))
def hook(uc,address,size,user):
 if address!=muldiv:return
 sp=uc.reg_read(UC_X86_REG_ESP);ret,a,b,d=struct.unpack('<4I',uc.mem_read(sp,16));assert d
 uc.reg_write(UC_X86_REG_EAX,(a*b+d//2)//d);uc.reg_write(UC_X86_REG_ESP,sp+16);uc.reg_write(UC_X86_REG_EIP,ret)
u.hook_add(UC_HOOK_CODE,hook)
def word(off,n):u.mem_write(player+off,struct.pack('<I',n))
for tick,last,rate,elapsed,expected in [(960,0,960,0,1000),(1440,960,480,1000,2000),(240,0,960,0,250)]:
 for off,n in [(0x18,tick),(0x1c,last),(0x20,rate),(0x28,elapsed)]:word(off,n)
 assert call(base+0x1d7f,player)==expected
# Real position and raw ticks don't subtract the 'start from first note' offset.
word(0x58,1);word(0x5c,200);assert call(base+0x1d7f,player)==250
print('Native clock passed: ticks, tempo change, seeking backwards and first-note offset.')
