#ifndef UNICODE
#define UNICODE
#define _UNICODE
#endif
#define NOMINMAX
#include "bridge.h"
#include "chords.h"
#include "chord_stream.h"
#include "capo.h"
#include "midi_timeline.h"
#include "player_lifetime.h"
#include <future>
#include <filesystem>
#include "theme_client.h"
#include "visual_settings.h"
#include <windowsx.h>
#include <gdiplus.h>
#include <commdlg.h>
#include <shellapi.h>
#include <sstream>
#include <deque>
#include <iomanip>
using namespace Gdiplus;
using MusicalChord=music::Chord;

namespace {
const Color bg(14,19,26),panel(23,31,41),edge(36,48,62),muted(144,161,179),softWhite(210,222,232),white(236,243,247),accent(106,237,197);
HWND win;Bridge bridge;NativeTheme nativeTheme;music::ChordStream stream;Snapshot snap;MusicalChord current,previous,nextChord;std::deque<MusicalChord> history;
bool frozen=false,leftHand=false,solfege=false,top=false,study=false;int channel=-1;
bool compact=true,mini=false,wasExpanded=false;DWORD lastConnect=0;bool simplified=true,slow=false;bool trayAdded=false;UINT taskbarCreated=0;constexpr UINT trayCallback=WM_APP+9;
bool capoEnabled=false;int capoFret=0;
PlayerLifetime playerLifetime;int beatsToNext=0;
std::wstring message;float uiScale=1;int offsetX=0,offsetY=0;
struct Hit{RectF r;int id;};std::vector<Hit> hits;
void text(Graphics&g,const std::wstring&s,float x,float y,float w,float h,float size,Color color=white,bool bold=false,StringAlignment align=StringAlignmentNear){
 FontFamily family(L"Segoe UI");Font font(&family,size,bold?FontStyleBold:FontStyleRegular,UnitPixel);SolidBrush brush(color);StringFormat fmt;
 fmt.SetAlignment(align);fmt.SetLineAlignment(StringAlignmentCenter);fmt.SetTrimming(StringTrimmingEllipsisCharacter);fmt.SetFormatFlags(StringFormatFlagsNoWrap);
 g.DrawString(s.c_str(),-1,&font,RectF(x,y,w,h),&fmt,&brush);
}
void rounded(Graphics&g,RectF r,Color c,float radius=12){GraphicsPath p;float d=radius*2;
 p.AddArc(r.X,r.Y,d,d,180,90);p.AddArc(r.GetRight()-d,r.Y,d,d,270,90);p.AddArc(r.GetRight()-d,r.GetBottom()-d,d,d,0,90);p.AddArc(r.X,r.GetBottom()-d,d,d,90,90);p.CloseFigure();SolidBrush b(c);g.FillPath(&b,&p);
}
void card(Graphics&g,RectF r,float radius=14){
 rounded(g,RectF(r.X,r.Y+4,r.Width,r.Height),Color(80,0,0,0),radius);
 GraphicsPath p;float d=radius*2;p.AddArc(r.X,r.Y,d,d,180,90);p.AddArc(r.GetRight()-d,r.Y,d,d,270,90);p.AddArc(r.GetRight()-d,r.GetBottom()-d,d,d,0,90);p.AddArc(r.X,r.GetBottom()-d,d,d,90,90);p.CloseFigure();
 SolidBrush fill(panel);Pen border(Color(52,65,80),1);g.FillPath(&fill,&p);g.DrawPath(&border,&p);
}
void line(Graphics&g,float x,float y,float xx,float yy,Color c,float width=1){Pen p(c,width);g.DrawLine(&p,x,y,xx,yy);}
void button(Graphics&g,int id,const std::wstring&label,float x,float y,float w,bool active=false,float h=30.f,bool onPanel=false){
 RectF r(x,y,w,h);
 Color fill=active?Color(24,54,54):(onPanel?Color(35,46,60):Color(25,34,45));
 Color fg=active?accent:softWhite;
 rounded(g,r,fill,7.f);
 text(g,label,x+5.f,y,w-10.f,h,11.5f,fg,true,StringAlignmentCenter);
 hits.push_back({r,id});
}
MusicalChord displayed(MusicalChord c){return capoEnabled?music::transposed(c,-capoFret):c;}
std::wstring displayedName(const MusicalChord&c){return c.valid()?music::name(displayed(c),solfege):L"Sem cifra";}
void diagram(Graphics&g,const MusicalChord&c,float x,float y,float w,float h,bool faded){
 MusicalChord shown=displayed(c);auto s=music::shape(shown);Color ink=faded?Color(127,146,162):white;Color grid=faded?Color(54,67,78):Color(78,94,110);
 if(!s.valid){text(g,c.valid()?L"Veja as notas no teclado":L"Aguardando um acorde",x,y+h/2-18,w,36,15,muted,false,StringAlignmentCenter);return;}
 int low=99,high=0;for(int f:s.fret)if(f>0){low=std::min(low,f);high=std::max(high,f);}
 int base=high<=4?1:low;float sx=w/7,dx=x+sx,dy=y+36,fh=(h-75)/4;
 for(int i=0;i<6;++i)line(g,dx+i*sx,dy,dx+i*sx,dy+4*fh,grid,1.2f+(5-i)*.18f);
 for(int f=0;f<=4;++f)line(g,dx,dy+f*fh,dx+5*sx,dy+f*fh,grid,f==0&&base==1?4:1.3f);
 if(base>1)text(g,std::to_wstring(base)+L"ª",x-9,dy,30,fh,12,muted);
 for(int finger=1;finger<=4;++finger){int first=6,last=-1,fret=-1;bool equal=true;
  for(int i=0;i<6;++i)if(s.finger[i]==finger&&s.fret[i]>0){if(fret>=0&&fret!=s.fret[i])equal=false;fret=s.fret[i];first=std::min(first,i);last=i;}
  if(equal&&last>first){float a=leftHand?5-last:first,b=leftHand?5-first:last;Pen p(faded?Color(91,110,124):accent,14);p.SetStartCap(LineCapRound);p.SetEndCap(LineCapRound);g.DrawLine(&p,dx+a*sx,dy+(fret-base+.5f)*fh,dx+b*sx,dy+(fret-base+.5f)*fh);}
 }
 static const wchar_t* strings[]={L"E",L"A",L"D",L"G",L"B",L"e"};
 for(int i=0;i<6;++i){int j=leftHand?5-i:i;float cx=dx+j*sx;
  text(g,strings[i],cx-12,dy+4*fh+10,24,20,11,muted,false,StringAlignmentCenter);
  int f=s.fret[i];
  if(f<0){line(g,cx-4,dy-20,cx+4,dy-12,ink,1.7f);line(g,cx+4,dy-20,cx-4,dy-12,ink,1.7f);}
  else if(f==0){Pen p(ink,1.7f);g.DrawEllipse(&p,cx-4,dy-20,8.f,8.f);}
  else {float cy=dy+(f-base+.5f)*fh;SolidBrush b(faded?Color(105,124,137):accent);g.FillEllipse(&b,cx-12,cy-12,24.f,24.f);text(g,std::to_wstring(s.finger[i]),cx-12,cy-12,24.f,24.f,14,bg,true,StringAlignmentCenter);}
 }
}
void keyboard(Graphics&g,float x,float y,float w,float h){
 int first=36,last=84;std::vector<int> whites;auto black=[](int n){int p=n%12;return p==1||p==3||p==6||p==8||p==10;};
 for(int n=first;n<=last;++n)if(!black(n))whites.push_back(n);float kw=w/whites.size();
 unsigned chordMask=music::mask(displayed(current));
 for(int i=0;i<(int)whites.size();++i){int n=whites[i];bool on=study?(chordMask&(1u<<(n%12)))!=0:snap.notes[n]>.1;
  rounded(g,RectF(x+i*kw+.7f,y,kw-1.4f,h),on?accent:Color(219,227,233),3);
  if(n%12==0)text(g,L"C"+std::to_wstring(n/12-1),x+i*kw,y+h-23,kw,18,9,Color(63,81,95),true,StringAlignmentCenter);
 }
 for(int i=0;i<(int)whites.size()-1;++i){int n=whites[i]+1;if(!black(n))continue;bool on=study?(chordMask&(1u<<(n%12)))!=0:snap.notes[n]>.1;
  rounded(g,RectF(x+(i+1)*kw-kw*.30f,y,kw*.60f,h*.61f),on?Color(53,177,153):Color(18,25,34),2);
 }
}
music::Timeline timeline;std::future<music::Timeline> pending;std::wstring songPath,analysisStatus;unsigned analysisMask=0;int analysisChannel=-2;bool analysisSimple=true,analysisSlow=false;uint32_t songPlayer=0;bool heldChord=false;std::wstring pendingPath;uint32_t pendingPlayer=0;
void updateAnalysis(const Snapshot&s){
 if(s.file!=songPath||s.playerId!=songPlayer){songPath=s.file;songPlayer=s.playerId;timeline={};nextChord={};current={};history.clear();previous={};stream.reset();capoEnabled=false;capoFret=0;analysisChannel=-2;analysisStatus=L"Analisando MIDI…";}
 if(pending.valid()&&pending.wait_for(std::chrono::seconds(0))==std::future_status::ready){auto loaded=pending.get();if(pendingPath==songPath&&pendingPlayer==songPlayer){timeline=std::move(loaded);analysisStatus=timeline.ready()?L"Sequência do MIDI":timeline.error;analysisChannel=-2;}}
 if(!pending.valid()&&!songPath.empty()&&analysisStatus==L"Analisando MIDI…"){
  pendingPath=songPath;pendingPlayer=songPlayer;auto path=songPath;
  pending=std::async(std::launch::async,[path](){music::Timeline t;try{std::ifstream f(std::filesystem::path(path),std::ios::binary|std::ios::ate);if(!f||f.tellg()<0||f.tellg()>32*1024*1024){t.error=L"Arquivo indisponível para pré-análise";return t;}size_t n=(size_t)f.tellg();std::vector<unsigned char>b(n);f.seekg(0);if(!f.read((char*)b.data(),n)){t.error=L"Não foi possível ler o MIDI";return t;}t.parse(b);}catch(...){t.error=L"Falha ao analisar MIDI";}return t;});
 }
 if(timeline.ready()&&(analysisMask!=(s.muted|s.drums)||analysisChannel!=channel||analysisSimple!=simplified||analysisSlow!=slow)){
  analysisMask=s.muted|s.drums;analysisChannel=channel;analysisSimple=simplified;analysisSlow=slow;
  timeline.analyze(analysisMask,channel,simplified,slow);
 }
}
std::wstring chordLabel(const MusicalChord&c){return displayedName(c);}
void countdown(Graphics&g,float x,float y,bool compactView){
 int lit=(nextChord.valid()&&beatsToNext>=1&&beatsToNext<=3)?beatsToNext:0;float d=compactView?8.f:10.f,gap=compactView?7.f:9.f;
 for(int i=0;i<3;++i){Color c=i<lit?accent:Color(55,70,84);SolidBrush b(c);g.FillEllipse(&b,x+i*(d+gap),y,d,d);}
}
void paintMini(Graphics&g){
 hits.clear();g.Clear(bg);g.SetSmoothingMode(SmoothingModeAntiAlias);g.SetTextRenderingHint(TextRenderingHintClearTypeGridFit);
 g.TranslateTransform((REAL)offsetX,(REAL)offsetY);g.ScaleTransform(uiScale,uiScale);
 card(g,RectF(4,4,322,88),12);rounded(g,RectF(4,4,5,88),accent,2);
 text(g,L"AGORA",22,12,110,18,9.5f,accent,true);
 text(g,chordLabel(current),20,30,125,48,current.valid()?32:14,white,true);
 line(g,154,18,154,78,edge,1);
 text(g,L"PRÓXIMO",174,12,124,18,9.5f,muted,true);
 text(g,nextChord.valid()?displayedName(nextChord):L"Sem próximo",172,32,126,36,nextChord.valid()?24:11,softWhite,true);
 countdown(g,198,72,true);
 text(g,L"Duplo clique para restaurar",10,96,310,18,9.5f,muted,false,StringAlignmentCenter);
}
void paintCompact(Graphics&g){
 hits.clear();g.Clear(bg);g.SetSmoothingMode(SmoothingModeAntiAlias);g.SetTextRenderingHint(TextRenderingHintClearTypeGridFit);
 g.TranslateTransform((REAL)offsetX,(REAL)offsetY);g.ScaleTransform(uiScale,uiScale);
 rounded(g,RectF(16,14,30,30),accent,9);text(g,L"v",16,12,30,32,20,bg,true,StringAlignmentCenter);
 text(g,L"Acordes",56,10,126,26,18,white,true);text(g,L"VANBASCO",57,31,120,13,8.5f,muted,true);
 SolidBrush dot(bridge.connected()?accent:muted);g.FillEllipse(&dot,184.f,24.f,6.f,6.f);
 text(g,bridge.connected()?L"CONECTADO":L"AGUARDANDO",195,15,61,24,8,bridge.connected()?accent:muted,true);
 button(g,14,L"Faixa",260,12,50,false,28.f);button(g,3,L"•••",316,12,28,false,28.f);
 card(g,RectF(16,54,328,136),14);rounded(g,RectF(16,54,5,136),accent,2);
 text(g,L"ACORDE ATUAL",32,68,178,15,9.5f,accent,true);
 text(g,chordLabel(current),30,84,190,62,current.valid()?48:21,white,true);
 text(g,current.valid()?(heldChord?L"Mantido entre notas":music::kinds()[current.kind].description):L"Sem harmonia identificada",32,148,184,20,11,muted);
 line(g,226,70,226,174,edge,1.f);
 text(g,L"PRÓXIMO",244,70,88,18,9.5f,muted,true);
 text(g,nextChord.valid()?displayedName(nextChord):L"Sem próximo",242,94,92,38,nextChord.valid()?24:10,softWhite,true);
 countdown(g,262,146,true);
 card(g,RectF(16,202,328,42),11);text(g,L"CAPOTRASTE",30,207,100,30,9.5f,muted,true);
 text(g,capoEnabled?L"Casa "+std::to_wstring(capoFret)+L" · cifras fáceis":L"Sugestão automática",126,207,105,30,10,capoEnabled?accent:softWhite,true,StringAlignmentFar);
 button(g,15,capoEnabled?L"Desligar":L"Calcular",238,208,92,capoEnabled,28.f);
 button(g,8,simplified?L"Básicos":L"Completo",16,256,104,simplified,30.f);button(g,9,slow?L"Suave":L"Rápido",128,256,104,slow,30.f);
 std::wstring label=channel<0?(timeline.ready()?L"Canais":(stream.source()<0?L"Auto":L"Auto · "+std::to_wstring(stream.source()+1))):L"Canal "+std::to_wstring(channel+1);
 button(g,5,label+L" ▾",240,256,104,false,30.f);
 std::wstring compactHint=!message.empty()?message:(frozen?L"Visual congelado":bridge.status);
 text(g,compactHint,18,292,324,18,9.5f,muted,false,StringAlignmentCenter);
}
void paint(Graphics&g){
 if(mini){paintMini(g);return;}
 if(compact){paintCompact(g);return;}
 hits.clear();g.Clear(bg);g.SetSmoothingMode(SmoothingModeAntiAlias);g.SetTextRenderingHint(TextRenderingHintClearTypeGridFit);
 g.TranslateTransform((REAL)offsetX,(REAL)offsetY);g.ScaleTransform(uiScale,uiScale);
 rounded(g,RectF(24,18,38,38),accent,10);text(g,L"v",24,16,38,40,24,bg,true,StringAlignmentCenter);
 text(g,L"vanBasco",76,16,220,27,22,white,true);text(g,L"PAINEL DE ACORDES",77,43,220,14,9,muted,true);
 std::wstring st=frozen?L"VISUAL CONGELADO":(bridge.connected()?L"MIDI SINCRONIZADO":L"AGUARDANDO PLAYER");
 SolidBrush dot(bridge.connected()?accent:muted);g.FillEllipse(&dot,357.f,33.f,7.f,7.f);
 text(g,st,372,23,190,26,10,bridge.connected()?accent:muted,true);
 button(g,14,L"Modo faixa",626,22,94,false,30.f);button(g,3,L"Opções",730,22,86,false,30.f);
 text(g,!message.empty()?message:bridge.status,25,70,790,22,10.5f,muted,false,StringAlignmentCenter);
 card(g,RectF(24,110,492,330),14);card(g,RectF(530,110,286,330),14);
 rounded(g,RectF(24,110,5,330),accent,2);
 text(g,L"ACORDE ATUAL",46,126,250,20,10.5f,accent,true);
 text(g,chordLabel(current),46,150,235,80,!current.valid()?28:(displayedName(current).size()>5?42:58),white,true);
 text(g,current.valid()?music::kinds()[current.kind].description:L"Sem harmonia suficiente",48,236,206,24,13.5f,muted);
 std::wstring notes;
 if(current.valid()){auto shown=displayed(current);for(int interval:music::kinds()[shown.kind].intervals){if(!notes.empty())notes+=L" · ";notes+=music::note(shown.root+interval,solfege);}}
 text(g,notes,48,272,200,28,13.5f,white);
 auto shownCurrent=displayed(current);
 text(g,shownCurrent.valid()&&shownCurrent.bass!=shownCurrent.root?L"Diagrama: posição básica":L"Afinação padrão · E A D G B e",48,316,206,22,11,muted);
 text(g,shownCurrent.valid()&&shownCurrent.bass!=shownCurrent.root?L"Baixo na cifra: "+music::note(shownCurrent.bass,solfege):L"1–4: dedos  ·  ○: solta  ·  ×: abafe",48,338,220,22,11,muted);
 diagram(g,current,262,144,213,274,false);
 text(g,L"PRÓXIMO ACORDE",552,126,240,20,10.5f,muted,true);
 text(g,nextChord.valid()?displayedName(nextChord):L"Sem próximo",552,152,240,44,nextChord.valid()?34:15,softWhite,true);
 countdown(g,570,202,false);
 diagram(g,nextChord,551,218,218,202,true);
 card(g,RectF(24,452,792,40),10);
 text(g,L"CAPOTRASTE",38,457,96,30,9.5f,muted,true);
 text(g,capoEnabled?L"Casa "+std::to_wstring(capoFret):L"Automático",130,457,82,30,10,capoEnabled?accent:softWhite,true);
 button(g,15,capoEnabled?L"Desligar":L"Calcular",214,458,86,capoEnabled,28.f);
 button(g,8,simplified?L"Básicos":L"Completo",310,458,110,simplified,28.f);button(g,9,slow?L"Suave":L"Rápido",430,458,110,slow,28.f);
 std::wstring cs=channel<0?(timeline.ready()?L"Todos os canais":(stream.source()<0?L"Canal automático":L"Auto · canal "+std::to_wstring(stream.source()+1))):L"Canal "+std::to_wstring(channel+1);
 button(g,5,cs+L"  ▾",550,458,252,false,28.f);
 keyboard(g,24,506,792,78);
 text(g,L"ÚLTIMOS ACORDES",25,600,220,20,10.5f,muted,true);
 float hx=24,used=0;int start=(int)history.size();
 for(int i=(int)history.size()-1;i>=0&&i>=(int)history.size()-8;--i){float needed=displayedName(history[i]).size()>4?103:81;if(used+needed>591)break;used+=needed;start=i;}
 for(int i=start;i<(int)history.size();++i){std::wstring s=displayedName(history[i]);float hw=s.size()>4?95:73;
  if(hx+hw>615)break;rounded(g,RectF(hx,628,hw,32),panel,8);text(g,s,hx+3,628,hw-6,32,13.5f,i==(int)history.size()-1?accent:white,true,StringAlignmentCenter);hx+=hw+8;
 }
 if(history.empty())text(g,L"A sequência aparece enquanto você toca a música.",24,626,580,32,12.5f,muted);
 button(g,6,L"Copiar cifras",635,628,116,false,32.f);button(g,7,L"Limpar",758,628,58,false,32.f);
 std::wstring hint=message;if(hint.empty()&&nativeTheme.error())hint=L"Aparência indisponível ("+std::to_wstring(nativeTheme.error())+L"). Extraia o ZIP completo e reinicie os dois programas.";
 if(!hint.empty())text(g,hint,24,676,792,22,11,muted);
}
void resetNotes(){stream.reset();snap.notes.fill(0);current={};nextChord={};beatsToNext=0;}
void accept(MusicalChord c){if(!music::same(current,c)){current=c;if(c.valid()&&(history.empty()||!music::same(history.back(),c))){if(!history.empty())previous=history.back();history.push_back(c);if(history.size()>256)history.pop_front();}}}
void togglePanel(bool forceShow=false){bool show=forceShow||!IsWindowVisible(win)||IsIconic(win);ShowWindow(win,show?SW_RESTORE:SW_MINIMIZE);if(show)SetForegroundWindow(win);nativeTheme.refresh(win);}
void addTray(){NOTIFYICONDATAW n{};n.cbSize=sizeof(n);n.hWnd=win;n.uID=1;n.uFlags=NIF_MESSAGE|NIF_ICON|NIF_TIP;n.uCallbackMessage=trayCallback;n.hIcon=LoadIconW(GetModuleHandleW(nullptr),MAKEINTRESOURCEW(1));lstrcpynW(n.szTip,L"vanBasco · Acordes — clique para restaurar/minimizar",128);trayAdded=Shell_NotifyIconW(NIM_ADD,&n)!=FALSE;}
void tick(){
 DWORD now=GetTickCount();
 if(!bridge.connected()&&now-lastConnect>=1500){lastConnect=now;bridge.connect();}
 Snapshot s;bool ok=bridge.poll(s,channel);
 if(bridge.connected())nativeTheme.update(bridge.window(),win);else nativeTheme.close();
 if(playerLifetime.update(now,bridge.connected())){DestroyWindow(win);return;}
 if(study||frozen)return;
 if(!ok){snap={};stream.reset();current={};nextChord={};heldChord=false;beatsToNext=0;}
 else{
  updateAnalysis(s);
  if(s.transpose!=snap.transpose){history.clear();previous={};stream.reset();}
  snap=s;
  if(timeline.ready()&&!timeline.segments.empty()&&s.division==timeline.division){
   auto view=timeline.viewAt(s.tick);heldChord=view.held;accept(music::transposed(view.current,s.transpose));nextChord=music::transposed(view.next,s.transpose);beatsToNext=music::countdownBeats(s.tick,view.nextTick,s.division);
   bridge.status=heldChord?L"Última harmonia mantida":(s.playing?L"MIDI sincronizado · canais do Output":L"Parado / pausado · sequência do MIDI");
  }else{
   nextChord={};heldChord=false;beatsToNext=0;
   if(s.playing)accept(stream.updateChannels(now,s.channels,channel));else stream.suspend();
   if(!analysisStatus.empty())bridge.status=analysisStatus;
  }
  if(!s.playing)snap.notes.fill(0);
 }
 if(IsWindowVisible(win))InvalidateRect(win,nullptr,FALSE);
}
void launch(const std::wstring&file=L""){
 visual::apply();
 std::wstring exe=folder()+L"vmidi.exe",params=file.empty()?L"":L"\""+file+L"\"";
 if(file.empty()&&bridge.connected()){HWND h=bridge.window();if(h){ShowWindow(h,SW_RESTORE);SetForegroundWindow(h);return;}}
 HINSTANCE r=ShellExecuteW(win,L"open",exe.c_str(),params.c_str(),folder().c_str(),SW_SHOWNORMAL);
 if((INT_PTR)r<=32)MessageBoxW(win,L"Não foi possível abrir vmidi.exe. Extraia a pasta inteira do ZIP antes de iniciar.",L"Abrir vanBasco",MB_OK|MB_ICONINFORMATION);
 lastConnect=0;
}
void toggleCapo(){
 if(capoEnabled){capoEnabled=false;capoFret=0;message=L"Capotraste desligado · cifras no tom real.";return;}
 std::vector<music::WeightedChord> material;
 if(timeline.ready()&&!timeline.segments.empty()){
  for(const auto& segment:timeline.segments)if(segment.chord.valid()){
   double beats=timeline.division?double(segment.end-segment.start)/timeline.division:1.0;
   material.push_back({segment.chord,std::max(.25,beats)});
  }
 }else{
  for(const auto& chord:history)if(chord.valid())material.push_back({chord,1});
  if(material.empty()&&current.valid())material.push_back({current,1});
 }
 if(material.empty()){
  MessageBoxW(win,L"Abra uma música e espere o primeiro acorde aparecer. Depois clique em Capotraste novamente.",L"Sugestão de capotraste",MB_OK|MB_ICONINFORMATION);
  return;
 }
 int soundingTranspose=(timeline.ready()&&!timeline.segments.empty())?snap.transpose:0;
 auto suggestion=music::suggestCapo(material,soundingTranspose,7);
 if(!suggestion.useful){
  MessageBoxW(win,L"Os acordes desta música já estão em formas fáceis. Não é necessário usar capotraste.",L"Sugestão de capotraste",MB_OK|MB_ICONINFORMATION);
  return;
 }
 capoFret=suggestion.fret;capoEnabled=true;
 MusicalChord example;
 if(current.valid())example=current;
 else for(const auto& item:material)if(item.chord.valid()){example=music::transposed(item.chord,soundingTranspose);break;}
 std::wstring detail=L"Coloque o capotraste na casa "+std::to_wstring(capoFret)+L".\n\n";
 if(example.valid())detail+=L"Exemplo: "+music::name(example,solfege)+L" vira "+music::name(displayed(example),solfege)+L" no painel.\n\n";
 detail+=L"O som do MIDI continua no tom original; apenas as cifras e os desenhos mudam para as posições mais fáceis. Clique no botão novamente para desligar.";
 MessageBoxW(win,detail.c_str(),L"Capotraste recomendado",MB_OK|MB_ICONINFORMATION);
 message=L"Capotraste na casa "+std::to_wstring(capoFret)+L" · cifras facilitadas.";
}
void popupOptions(){HMENU m=CreatePopupMenu();AppendMenuW(m,MF_STRING|(top?MF_CHECKED:0),101,L"Sempre por cima");AppendMenuW(m,MF_STRING|(leftHand?MF_CHECKED:0),102,L"Violão para canhotos");AppendMenuW(m,MF_STRING|(solfege?MF_CHECKED:0),103,L"Nomes Dó, Ré, Mi");AppendMenuW(m,MF_STRING|(frozen?MF_CHECKED:0),104,L"Congelar / retomar visual");AppendMenuW(m,MF_SEPARATOR,0,nullptr);AppendMenuW(m,MF_STRING,105,L"Como usar");AppendMenuW(m,MF_STRING,106,L"Restaurar cores/fontes anteriores do karaokê");AppendMenuW(m,MF_SEPARATOR,0,nullptr);AppendMenuW(m,MF_STRING,107,L"Encerrar complemento");POINT p;GetCursorPos(&p);int cmd=TrackPopupMenu(m,TPM_RETURNCMD|TPM_RIGHTBUTTON,p.x,p.y,0,win,nullptr);DestroyMenu(m);
 if(cmd==101){top=!top;SetWindowPos(win,top?HWND_TOPMOST:HWND_NOTOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE);}if(cmd==102)leftHand=!leftHand;if(cmd==103)solfege=!solfege;if(cmd==104){frozen=!frozen;if(!frozen)resetNotes();}
 if(cmd==105)MessageBoxW(win,L"Básicos mantém maiores e menores: Am7 vira Am; Cmaj7 vira C. Suspensos e diminutos também são preservados. Completo mostra as extensões.\n\nA análise do MIDI pondera os canais harmônicos, baixo, duração das notas e pedal. Os canais silenciados no Output ficam fora. Se a cifra não combinar, escolha o canal de piano/violão. O próximo acorde vem da sequência pré-analisada do MIDI.\n\nAs três bolinhas acendem em contagem regressiva: 3, 2, 1 tempos até a troca. Quando a mudança está mais distante, ficam apagadas.\n\nCapotraste analisa a sequência inteira, procura formas mais fáceis entre as casas 1 e 7 e muda apenas as cifras e desenhos. O áudio continua no tom original. A faixa informa a casa escolhida; use Desligar para voltar às cifras reais.\n\nPré-análise rápida: um tempo por janela. Suave: dois tempos. Leitura ao vivo de reserva: 160/320 ms. A pré-análise reúne notas por tempo musical e mantém breves lacunas. Sem evidência suficiente, mostra Sem cifra.\n\nO Modo faixa deixa somente o acorde atual e o próximo. Dê duplo clique nessa faixa para restaurar a janela. O X minimiza o painel; restaure pelo botão Acordes no player, pela barra de tarefas ou pelo ícone junto ao relógio. Ao fechar o vanBasco, o complemento também encerra.",L"Como usar",MB_OK|MB_ICONINFORMATION);
 if(cmd==106){if(FindWindowW(L"vanBascoPlayerClass",nullptr)){MessageBoxW(win,L"Feche o vanBasco e use esta opção novamente para restaurar apenas as cores e fontes do karaokê.",L"Restaurar aparência",MB_OK);}else{bool ok=visual::restore();MessageBoxW(win,ok?L"A aparência anterior do karaokê foi restaurada. Abra o player novamente.":L"Não foi possível restaurar a aparência. Verifique se esta versão já foi usada neste usuário.",L"Restaurar aparência",MB_OK);}}
 if(cmd==107)DestroyWindow(win);
}
void selectStudy(){if(study){study=false;frozen=false;resetNotes();return;}HMENU m=CreatePopupMenu();for(int r=0;r<12;++r){HMENU sub=CreatePopupMenu();for(int k=0;k<(int)music::kinds().size();++k){if(simplified&&k!=0&&k!=1&&k!=5&&k!=6&&k!=7&&k!=8)continue;MusicalChord c{r,k,r,1};AppendMenuW(sub,MF_STRING,1000+r*32+k,music::name(c,solfege).c_str());}AppendMenuW(m,MF_POPUP,(UINT_PTR)sub,music::note(r,solfege).c_str());}
 POINT p;GetCursorPos(&p);int id=TrackPopupMenu(m,TPM_RETURNCMD|TPM_RIGHTBUTTON,p.x,p.y,0,win,nullptr);DestroyMenu(m);if(id>=1000){id-=1000;study=true;frozen=false;nextChord={};heldChord=false;snap.notes.fill(0);accept({id/32,id%32,id/32,1});}
}
void command(int id){message.clear();if(id==1){wchar_t file[32768]={};OPENFILENAMEW o{};o.lStructSize=sizeof(o);o.hwndOwner=win;o.lpstrFilter=L"Música MIDI / Karaoke\0*.mid;*.midi;*.kar;*.rmi\0Todos os arquivos\0*.*\0";o.lpstrFile=file;o.nMaxFile=32768;o.Flags=OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST|OFN_NOCHANGEDIR;if(GetOpenFileNameW(&o)){study=false;frozen=false;resetNotes();history.clear();previous={};launch(file);}}
 if(id==2)launch();if(id==3)popupOptions();if(id==4)selectStudy();
 if(id==15)toggleCapo();
 if(id==5){HMENU m=CreatePopupMenu();AppendMenuW(m,MF_STRING|(channel<0?MF_CHECKED:0),200,L"Automático: canais do Output (sem bateria)");for(int ch=0;ch<16;++ch){std::wstring label=L"Canal "+std::to_wstring(ch+1);if(ch==9)label+=L" (geralmente bateria)";AppendMenuW(m,MF_STRING|(channel==ch?MF_CHECKED:0),201+ch,label.c_str());}POINT p;GetCursorPos(&p);int choice=TrackPopupMenu(m,TPM_RETURNCMD,p.x,p.y,0,win,nullptr);DestroyMenu(m);if(choice>=200){channel=choice-201;resetNotes();study=false;}}
 if(id==6){if(history.empty()){message=L"Ainda não há cifras para copiar.";}else{
  std::wstring s;if(capoEnabled)s=L"Capotraste: casa "+std::to_wstring(capoFret)+L"\r\n";for(auto&c:history){if(!s.empty()&&s.back()!=L'\n')s+=L"  |  ";s+=displayedName(c);}if(OpenClipboard(win)){HGLOBAL h=GlobalAlloc(GMEM_MOVEABLE,(s.size()+1)*sizeof(wchar_t));if(h){void*p=GlobalLock(h);if(p){memcpy(p,s.c_str(),(s.size()+1)*sizeof(wchar_t));GlobalUnlock(h);EmptyClipboard();if(SetClipboardData(CF_UNICODETEXT,h))message=L"Cifras copiadas. Cole com Ctrl+V.";else GlobalFree(h);}else GlobalFree(h);}CloseClipboard();}
 }}
 if(id>=10&&id<=12){
  if(study){study=false;resetNotes();}frozen=false;
  HWND player=bridge.connected()?bridge.window():nullptr;
  if(!player)message=L"Abra o player e um arquivo MIDI para transpor.";
  else{int amount=id==10?-1:id==11?1:-snap.transpose;amount=std::max(-24,std::min(24,amount));for(int i=0;i<std::abs(amount);++i)PostMessageW(player,WM_COMMAND,amount>0?0x8014:0x8015,0);}
 }
 if(id==13){mini=false;RECT area;SystemParametersInfo(SPI_GETWORKAREA,0,&area,0);int w=compact?std::min(856L,area.right-area.left):460,h=compact?std::min(766L,area.bottom-area.top):440;SetWindowPos(win,nullptr,area.left+(area.right-area.left-w)/2,area.top+(area.bottom-area.top-h)/2,w,h,SWP_NOZORDER);}
 if(id==14){
  if(!mini){wasExpanded=!compact;mini=true;SetWindowPos(win,nullptr,0,0,360,155,SWP_NOMOVE|SWP_NOZORDER);}
  else{mini=false;RECT area;SystemParametersInfo(SPI_GETWORKAREA,0,&area,0);int w=wasExpanded?std::min(856L,area.right-area.left):460,h=wasExpanded?std::min(766L,area.bottom-area.top):440;SetWindowPos(win,nullptr,0,0,w,h,SWP_NOMOVE|SWP_NOZORDER);}
 }
 if(id==7){history.clear();previous={};}
 if(id==8||id==9){if(id==8)simplified=!simplified;else slow=!slow;stream.settings(simplified,slow);current={};nextChord={};previous={};history.clear();study=false;frozen=false;}InvalidateRect(win,nullptr,FALSE);
}
LRESULT CALLBACK proc(HWND h,UINT msg,WPARAM w,LPARAM l){
 if(msg==toggleMessage()){togglePanel(w==1);return 0;}
 if(taskbarCreated&&msg==taskbarCreated){addTray();return 0;}
 switch(msg){
 case WM_CLOSE:ShowWindow(h,SW_MINIMIZE);nativeTheme.refresh(h);return 0;
 case trayCallback:
  if(l==WM_LBUTTONUP)togglePanel();
  if(l==WM_RBUTTONUP){HMENU menu=CreatePopupMenu();AppendMenuW(menu,MF_STRING,1,IsIconic(h)?L"Restaurar acordes":L"Minimizar acordes");AppendMenuW(menu,MF_STRING,2,L"Abrir player");AppendMenuW(menu,MF_SEPARATOR,0,nullptr);AppendMenuW(menu,MF_STRING,3,L"Encerrar complemento");POINT p;GetCursorPos(&p);SetForegroundWindow(h);int id=TrackPopupMenu(menu,TPM_RETURNCMD|TPM_RIGHTBUTTON,p.x,p.y,0,h,nullptr);DestroyMenu(menu);if(id==1)togglePanel();if(id==2)launch();if(id==3)DestroyWindow(h);PostMessageW(h,WM_NULL,0,0);}return 0;
 case WM_CREATE:{win=h;HINSTANCE instance=GetModuleHandleW(nullptr);SendMessageW(h,WM_SETICON,ICON_BIG,(LPARAM)LoadIconW(instance,MAKEINTRESOURCEW(1)));SendMessageW(h,WM_SETICON,ICON_SMALL,(LPARAM)LoadImageW(instance,MAKEINTRESOURCEW(1),IMAGE_ICON,16,16,LR_DEFAULTCOLOR));taskbarCreated=RegisterWindowMessageW(L"TaskbarCreated");addTray();SetTimer(h,1,40,nullptr);SetTimer(h,2,350,nullptr);return 0;}
 case WM_TIMER:if(w==2){KillTimer(h,2);launch();}else tick();return 0;
 case WM_SIZE:{RECT r;GetClientRect(h,&r);float bw,bh;if(mini){bw=330.f;bh=120.f;}else{compact=r.right<700||r.bottom<610;bw=compact?360.f:840.f;bh=compact?320.f:720.f;}uiScale=std::min(r.right/bw,r.bottom/bh);offsetX=(int)((r.right-bw*uiScale)/2);offsetY=(int)((r.bottom-bh*uiScale)/2);InvalidateRect(h,nullptr,FALSE);return 0;}
 case WM_GETMINMAXINFO:{auto*p=(MINMAXINFO*)l;p->ptMinTrackSize=mini?POINT{340,145}:POINT{320,300};return 0;}
 case WM_ERASEBKGND:return 1;
 case WM_PAINT:{PAINTSTRUCT p;HDC dc=BeginPaint(h,&p);RECT r;GetClientRect(h,&r);HDC mem=CreateCompatibleDC(dc);HBITMAP bm=CreateCompatibleBitmap(dc,std::max(1L,r.right),std::max(1L,r.bottom));HGDIOBJ old=SelectObject(mem,bm);{Graphics g(mem);paint(g);}BitBlt(dc,0,0,r.right,r.bottom,mem,0,0,SRCCOPY);SelectObject(mem,old);DeleteObject(bm);DeleteDC(mem);EndPaint(h,&p);return 0;}
 case WM_LBUTTONUP:{float x=(GET_X_LPARAM(l)-offsetX)/uiScale,y=(GET_Y_LPARAM(l)-offsetY)/uiScale;for(auto b:hits)if(b.r.Contains(x,y)){command(b.id);break;}return 0;}
 case WM_LBUTTONDBLCLK:if(mini){command(14);return 0;}break;
 case WM_SETCURSOR:if(LOWORD(l)==HTCLIENT){POINT p;GetCursorPos(&p);ScreenToClient(h,&p);float x=(p.x-offsetX)/uiScale,y=(p.y-offsetY)/uiScale;for(auto b:hits)if(b.r.Contains(x,y)){SetCursor(LoadCursor(nullptr,IDC_HAND));return TRUE;}}break;
 case WM_KEYDOWN:if(w==VK_F1)command(3);if(w=='O'&&(GetKeyState(VK_CONTROL)&0x8000))command(1);if(w=='C'&&(GetKeyState(VK_CONTROL)&0x8000))command(6);return 0;
 case WM_DESTROY:win=nullptr;KillTimer(h,1);KillTimer(h,2);nativeTheme.close();bridge.close();{NOTIFYICONDATAW n{};n.cbSize=sizeof(n);n.hWnd=h;n.uID=1;Shell_NotifyIconW(NIM_DELETE,&n);}PostQuitMessage(0);return 0;
 }return DefWindowProcW(h,msg,w,l);}
}
int WINAPI wWinMain(HINSTANCE instance,HINSTANCE,LPWSTR args,int show){
 SetProcessDPIAware();ULONG_PTR token;GdiplusStartupInput input;GdiplusStartup(&token,&input,nullptr);
 bool preview=std::wstring(args).find(L"--preview")!=std::wstring::npos;
 if(preview){study=true;current={7,0,7,1};previous={0,0,0,1};history={{0,0,0,1},{9,1,9,1},{5,0,5,1},current};}
 HANDLE mutex=CreateMutexW(nullptr,FALSE,L"Local\\VanBascoAcordesCompanion01");if(GetLastError()==ERROR_ALREADY_EXISTS){HWND existing=FindWindowW(L"VanBascoAcordesWindow",nullptr);if(existing){PostMessageW(existing,toggleMessage(),1,0);ShowWindow(existing,SW_RESTORE);SetForegroundWindow(existing);}CloseHandle(mutex);GdiplusShutdown(token);return 0;}
 WNDCLASSW wc{};wc.style=CS_DBLCLKS;wc.lpfnWndProc=proc;wc.hInstance=instance;wc.lpszClassName=L"VanBascoAcordesWindow";wc.hCursor=LoadCursor(nullptr,IDC_ARROW);wc.hIcon=LoadIconW(instance,MAKEINTRESOURCEW(1));RegisterClassW(&wc);
 RECT work;SystemParametersInfo(SPI_GETWORKAREA,0,&work,0);int height=std::min(440L,work.bottom-work.top-20),width=460;
 HWND h=CreateWindowExW(0,wc.lpszClassName,L"Acordes para vanBasco",WS_OVERLAPPEDWINDOW,(work.right-width)/2,(work.bottom-height)/2,width,height,nullptr,nullptr,instance,nullptr);
 if(preview)KillTimer(h,2);ShowWindow(h,show);UpdateWindow(h);
 MSG m;while(GetMessageW(&m,nullptr,0,0)>0){TranslateMessage(&m);DispatchMessageW(&m);}CloseHandle(mutex);GdiplusShutdown(token);return 0;
}
