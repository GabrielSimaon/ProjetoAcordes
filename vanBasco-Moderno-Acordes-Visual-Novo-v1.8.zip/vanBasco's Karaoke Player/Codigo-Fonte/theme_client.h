#pragma once
#include "theme_protocol.h"
class NativeTheme {
 HMODULE dll=nullptr;HHOOK hook=nullptr;HWND target=nullptr;DWORD last=0,lastAttempt=0,errorCode=0;bool attempted=false;
public:
 ~NativeTheme(){close();if(dll)FreeLibrary(dll);}
 void close(){if(hook)UnhookWindowsHookEx(hook);hook=nullptr;target=nullptr;attempted=false;errorCode=0;}
 DWORD error()const{return errorCode;}
 bool update(HWND player,HWND panel){
  if(player!=target){close();target=player;}
  if(!IsWindow(player)){close();return false;}
  if(!hook){
   DWORD now=GetTickCount();if(attempted&&now-lastAttempt<5000)return false;
   attempted=true;lastAttempt=now;
   if(!dll){DWORD oldMode=0;BOOL changed=SetThreadErrorMode(SEM_FAILCRITICALERRORS,&oldMode);
    dll=LoadLibraryW((folder()+L"VisualModerno.dll").c_str());errorCode=dll?0:GetLastError();
    if(changed)SetThreadErrorMode(oldMode,nullptr);
   }
   if(!dll)return false;auto fn=(HOOKPROC)GetProcAddress(dll,"ThemeHook");
   if(!fn){errorCode=GetLastError();return false;}hook=SetWindowsHookExW(WH_CALLWNDPROC,fn,dll,GetWindowThreadProcessId(player,nullptr));
   if(!hook){errorCode=GetLastError();return false;}errorCode=0;last=GetTickCount()-1000;
  }
  if(GetTickCount()-last>=1000){last=GetTickCount();PostMessageW(player,themeMessage(),(WPARAM)panel,0);}
  return IsWindow((HWND)GetPropW(player,toggleProperty));
 }
 void refresh(HWND panel){if(IsWindow(target))PostMessageW(target,themeMessage(),(WPARAM)panel,0);}
};
