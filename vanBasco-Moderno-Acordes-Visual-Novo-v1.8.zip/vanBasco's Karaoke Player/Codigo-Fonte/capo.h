#pragma once
#include "chord_stream.h"
#include <vector>
#include <cmath>

namespace music {

struct WeightedChord {
 Chord chord;
 double weight=1.0;
};

struct CapoSuggestion {
 int fret=0;
 double originalCost=0;
 double suggestedCost=0;
 bool useful=false;
};

// A small practical model of common guitar shapes. Lower is easier.
// The chord quality still matters, but the root/shape has the greatest weight.
inline double guitarShapeCost(const Chord& chord) {
 if(!chord.valid())return 0;
 static const double major[12]={0.0,4.0,0.4,3.4,0.2,1.7,3.7,0.0,3.5,0.2,3.6,3.0};
 static const double minor[12]={2.1,3.8,0.7,3.3,0.1,2.8,2.5,1.8,3.6,0.0,3.2,1.4};
 int simple=basicKind(chord.kind);
 double cost=(simple==1?minor:major)[(chord.root%12+12)%12];
 if(simple!=0&&simple!=1)cost+=0.55;
 if(chord.bass>=0&&chord.bass!=chord.root)cost+=0.45;
 return cost;
}

inline CapoSuggestion suggestCapo(const std::vector<WeightedChord>& chords,int soundingTranspose=0,int maxFret=7) {
 CapoSuggestion result;
 double totalWeight=0;
 auto costAt=[&](int fret){
  double cost=0;
  for(const auto& item:chords)if(item.chord.valid()&&item.weight>0){
   Chord sounding=transposed(item.chord,soundingTranspose);
   cost+=guitarShapeCost(transposed(sounding,-fret))*item.weight;
  }
  return cost;
 };
 for(const auto& item:chords)if(item.chord.valid()&&item.weight>0)totalWeight+=item.weight;
 if(totalWeight<=0)return result;
 result.originalCost=costAt(0)/totalWeight;
 double best=result.originalCost;
 for(int fret=1;fret<=maxFret;++fret){
  // Prefer the lowest useful fret when two options have similar shapes.
  double average=costAt(fret)/totalWeight;
  double ranked=average+fret*.075;
  double bestRanked=best+result.fret*.075;
  if(ranked+1e-9<bestRanked){best=average;result.fret=fret;}
 }
 result.suggestedCost=best;
 result.useful=result.fret>0&&(result.originalCost-result.suggestedCost>=0.45||result.suggestedCost<=result.originalCost*.72);
 if(!result.useful){result.fret=0;result.suggestedCost=result.originalCost;}
 return result;
}

}
