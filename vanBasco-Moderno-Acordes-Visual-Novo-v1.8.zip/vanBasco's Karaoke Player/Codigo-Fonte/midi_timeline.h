#pragma once
#include "chord_stream.h"
#include <map>
#include <stdexcept>
#include <cstdint>
namespace music {
struct MidiNote{uint32_t start,end;int ch,key,velocity,program;};
struct Segment{uint32_t start,end;Chord chord;bool held=false;};
struct TimelineView{Chord current,next;uint32_t nextTick=0;bool held=false;};
inline int countdownBeats(uint32_t tick,uint32_t nextTick,unsigned division){
 if(!division||nextTick<=tick)return 0;
 uint32_t beats=(nextTick-tick+division-1)/division;
 return int(std::min<uint32_t>(4,beats));
}
struct Timeline{
 unsigned division=0;uint32_t end=0;std::vector<MidiNote> notes;std::vector<Segment> segments;std::wstring error;
 bool ready()const{return division&&!notes.empty();}
 bool parse(const std::vector<unsigned char>& input){
  *this={};try{
   size_t base=0,limit=input.size();auto be=[&](size_t p,int n){if(p+n>limit)throw 1;uint32_t v=0;while(n--)v=(v<<8)|input[p++];return v;};
   auto tag=[&](size_t p,const char*s){return p+4<=limit&&std::equal(input.begin()+p,input.begin()+p+4,s);};
   if(tag(0,"RIFF")){if(!tag(8,"RMID"))throw 1;size_t p=12;bool found=false;while(p+8<=limit){uint32_t n=input[p+4]|input[p+5]<<8|input[p+6]<<16|uint32_t(input[p+7])<<24;if(n>limit-p-8)throw 1;if(tag(p,"data")){base=p+8;limit=base+n;found=true;break;}p+=8+n+(n&1);}if(!found)throw 1;}
   if(!tag(base,"MThd")||be(base+4,4)<6)throw 1;
   int format=be(base+8,2),tracks=be(base+10,2);division=be(base+12,2);if(format>1||!division||(division&0x8000)||tracks>1024)throw 1;
   struct E{uint32_t tick;int status,a,b;};std::vector<E> events;size_t p=base+8+be(base+4,4);
   for(int tr=0;tr<tracks;++tr){if(!tag(p,"MTrk"))throw 1;uint32_t n=be(p+4,4);p+=8;if(n>limit-p)throw 1;size_t stop=p+n;uint32_t tick=0;int running=0;
    auto byte=[&](){if(p>=stop)throw 1;return int(input[p++]);};
    auto vlq=[&](){uint32_t v=0;for(int i=0;i<4;++i){int b=byte();v=(v<<7)|(b&127);if(!(b&128))return v;}throw 1;};
    while(p<stop){uint32_t dt=vlq();if(dt>0xffffffff-tick)throw 1;tick+=dt;end=std::max(end,tick);int st=byte();if(st<128){if(!running)throw 1;--p;st=running;}
     if(st==255){int type=byte();uint32_t n=vlq();if(n>stop-p)throw 1;p+=n;if(type==47){p=stop;break;}continue;}
     if(st==240||st==247){running=0;uint32_t n=vlq();if(n>stop-p)throw 1;p+=n;continue;}
     if(st<128||st>=240)throw 1;running=st;int a=byte(),b=((st&240)==192||(st&240)==208)?0:byte();if(a>127||b>127)throw 1;
     events.push_back({tick,st,a,b});if(events.size()>2000000)throw 1;
    }
   }
   std::stable_sort(events.begin(),events.end(),[](auto&a,auto&b){return a.tick<b.tick;});
   struct Voice{uint32_t start;int vel,program;bool released;};std::map<int,std::vector<Voice>> active;bool pedal[16]{};int program[16]{};
   auto finish=[&](int id,Voice v,uint32_t at){if(at>v.start)notes.push_back({v.start,at,id/128,id%128,v.vel,v.program});};
   for(auto&e:events){int ch=e.status&15,type=e.status&240,id=ch*128+e.a;
    if(type==192)program[ch]=e.a;
    if(type==144&&e.b){active[id].push_back({e.tick,e.b,program[ch],false});}
    if(type==128||(type==144&&!e.b)){auto&v=active[id];auto it=std::find_if(v.begin(),v.end(),[](auto&x){return !x.released;});if(it!=v.end()){if(pedal[ch])it->released=true;else{finish(id,*it,e.tick);v.erase(it);}}}
    if(type==176){bool release=e.a==64&&e.b<64;bool all=e.a==120||e.a==123;if(e.a==64)pedal[ch]=e.b>=64;
     if(release||all)for(auto&kv:active)if(kv.first/128==ch){auto&v=kv.second;for(auto it=v.begin();it!=v.end();)if(all||it->released){finish(kv.first,*it,e.tick);it=v.erase(it);}else ++it;}
    }
   }
   for(auto&kv:active)for(auto v:kv.second)finish(kv.first,v,end);
   if(notes.empty())throw 1;std::sort(notes.begin(),notes.end(),[](auto&a,auto&b){return a.start<b.start;});return true;
  }catch(...){division=0;notes.clear();segments.clear();error=L"MIDI não analisável (formato ou limite)";return false;}
 }
 void analyze(unsigned excluded=512,int channel=-1,bool simple=true,bool slow=false){
  segments.clear();if(!ready())return;
  uint32_t step=std::max(1u,division*(slow?2:1));size_t bins=size_t(end)/step+1;if(bins>20000){error=L"MIDI longo demais para pré-análise";return;}
  using PCs=std::array<double,12>;struct Bin{std::array<PCs,16> pc{};PCs bass{};int count=0;};std::vector<Bin> data(bins);
  double strength[16]{};int poly[16]{};std::array<int,16> programs{};
  for(auto&n:notes){if((excluded&(1u<<n.ch))||(channel>=0&&n.ch!=channel))continue;programs[n.ch]=n.program;
   size_t a=n.start/step,b=std::min(bins-1,size_t((n.end-1)/step));if(b-a>10000)continue;
   for(size_t k=a;k<=b;++k){double d=double(std::min(n.end,uint32_t((k+1)*step))-std::max(n.start,uint32_t(k*step)))/step;
    data[k].pc[n.ch][n.key%12]+=d*(.5+n.velocity/254.0);data[k].count++;
    if(n.key<55||n.program>=32&&n.program<=39)data[k].bass[n.key%12]+=d;
   }
  }
  for(auto&b:data)for(int ch=0;ch<16;++ch){int distinct=0;for(double w:b.pc[ch])if(w>.08)++distinct;if(distinct>=3)poly[ch]++;strength[ch]+=distinct;}
  // Score duration-weighted pitch classes. Harmonic channels dominate solos;
  // bass helps disambiguate inversions. All non-muted output channels remain evidence.
  Chord previous;int gaps=0;
  for(size_t k=0;k<bins;++k){PCs weights{};bool sound=data[k].count>0;
   for(int ch=0;ch<16;++ch){double factor=channel>=0?1:(poly[ch]>int(bins*.05)?1.6:.55);if(programs[ch]>=80&&programs[ch]<88)factor*=.5;
    for(int pc=0;pc<12;++pc){double w=data[k].pc[ch][pc];
     // Analyze inside this beat only; future notes must not advance a change.
     weights[pc]+=w*factor;
    }
   }
   double total=0;int distinct=0;for(double w:weights){total+=w;if(w>.12)++distinct;}
   Chord best;double bestScore=-1e9;
   if(sound&&distinct>=3&&total>.4)for(int root=0;root<12;++root)for(int kind=0;kind<(int)kinds().size();++kind){
    if(simple&&kind!=0&&kind!=1&&kind!=5&&kind!=6&&kind!=7&&kind!=8)continue;
    Chord c{root,kind,root,0};unsigned m=mask(c);double covered=0;int missing=0;for(int pc=0;pc<12;++pc)if(m&(1u<<pc)){covered+=weights[pc];if(weights[pc]<.10)++missing;}
    if(missing||covered/total<.68)continue;
    double score=(covered-(total-covered)*1.65)/total + .08*std::min(1.0,data[k].bass[root]);
    score-=.035*(bits(m)-3);if(root==previous.root&&basicKind(kind)==basicKind(previous.kind))score+=.035;
    if(score>bestScore){bestScore=score;c.confidence=covered/total;best=c;}
   }
   bool held=false;
   if(!best.valid()){++gaps;if(previous.valid()&&gaps*step<=division*2){best=previous;held=true;}}
   else gaps=0;
   uint32_t start=uint32_t(k*step),stop=std::min(end,uint32_t((k+1)*step));if(stop<=start)continue;
   if(!segments.empty()&&same(segments.back().chord,best)&&segments.back().held==held)segments.back().end=stop;else segments.push_back({start,stop,best,held});
   if(best.valid())previous=best;
  }
 }
 TimelineView viewAt(uint32_t tick)const{
  TimelineView view;if(tick>=end)return view;
  auto it=std::upper_bound(segments.begin(),segments.end(),tick,[](uint32_t t,const Segment&s){return t<s.start;});
  if(it!=segments.begin()){--it;if(tick<it->end){view.current=it->chord;view.held=it->held;}}
  for(;it!=segments.end();++it)if(it->start>tick&&it->chord.valid()&&!same(it->chord,view.current)){view.next=it->chord;view.nextTick=it->start;break;}
  return view;
 }
 std::pair<Chord,Chord> at(uint32_t tick,bool* held=nullptr)const{
  auto view=viewAt(tick);if(held)*held=view.held;return {view.current,view.next};
 }
};
}
