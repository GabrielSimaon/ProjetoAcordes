#pragma once
#include <array>
#include <vector>
#include <string>
#include <algorithm>
#include <cmath>

namespace music {
struct Kind { const char* suffix; const wchar_t* description; std::vector<int> intervals; };
inline const std::vector<Kind>& kinds() {
 static const std::vector<Kind> k={
  {"",L"Maior",{0,4,7}}, {"m",L"Menor",{0,3,7}},
  {"7",L"Sétima dominante",{0,4,7,10}}, {"m7",L"Menor com sétima",{0,3,7,10}},
  {"maj7",L"Sétima maior",{0,4,7,11}}, {"sus2",L"Segunda suspensa",{0,2,7}},
  {"sus4",L"Quarta suspensa",{0,5,7}}, {"dim",L"Diminuto",{0,3,6}},
  {"aug",L"Aumentado",{0,4,8}}, {"m7b5",L"Meio diminuto",{0,3,6,10}},
  {"dim7",L"Sétima diminuta",{0,3,6,9}}, {"6",L"Maior com sexta",{0,4,7,9}},
  {"m6",L"Menor com sexta",{0,3,7,9}}, {"add9",L"Nona adicionada",{0,2,4,7}},
  {"9",L"Nona dominante",{0,2,4,7,10}}, {"m9",L"Menor com nona",{0,2,3,7,10}}
 };return k;
}
struct Chord { int root=-1, kind=0, bass=-1; double confidence=0; bool valid()const{return root>=0;} };
inline bool same(const Chord&a,const Chord&b){return a.root==b.root&&a.kind==b.kind&&a.bass==b.bass;}
inline unsigned mask(const Chord&c){unsigned m=0;if(c.valid())for(int n:kinds()[c.kind].intervals)m|=1u<<((c.root+n)%12);return m;}
inline int bits(unsigned n){int c=0;for(;n;n&=n-1)++c;return c;}
inline std::wstring note(int n,bool solfege=false){
 static const wchar_t* en[]={L"C",L"C#",L"D",L"Eb",L"E",L"F",L"F#",L"G",L"Ab",L"A",L"Bb",L"B"};
 static const wchar_t* pt[]={L"Dó",L"Dó#",L"Ré",L"Mib",L"Mi",L"Fá",L"Fá#",L"Sol",L"Láb",L"Lá",L"Sib",L"Si"};
 return (solfege?pt:en)[(n%12+12)%12];
}
inline std::wstring name(const Chord&c,bool solfege=false){
 if(!c.valid())return L"—";std::string s=kinds()[c.kind].suffix;
 std::wstring r=note(c.root,solfege)+std::wstring(s.begin(),s.end());
 if(c.bass>=0&&c.bass!=c.root)r+=L"/"+note(c.bass,solfege);return r;
}
inline int basicKind(int kind){switch(kind){case 2:case 4:case 11:case 13:case 14:return 0;case 3:case 12:case 15:return 1;case 9:case 10:return 7;default:return kind;}}
// Complete chord templates, with a small allowance for a passing melody note.
// The bass resolves common ambiguities such as C6 / Am7.
inline Chord detect(const std::array<double,128>&notes,const Chord&previous={},bool conservative=false){
 double weight[12]={};unsigned present=0;int bass=-1;
 for(int n=0;n<128;++n)if(notes[n]>0.12){weight[n%12]+=notes[n];present|=1u<<(n%12);if(bass<0)bass=n%12;}
 int count=bits(present);Chord best;double bestScore=-1e9;std::vector<std::pair<Chord,double>> ranked;
 if(count<3||count>6)return best;
 for(int root=0;root<12;++root)for(int k=0;k<(int)kinds().size();++k){
  Chord c{root,k,bass,0};unsigned wanted=mask(c);
  if((present&wanted)!=wanted)continue;
  int extras=bits(present&~wanted);if(extras>1)continue;
  double score=bits(wanted)*2.8-extras*3.4+(bass==root?1.8:0);
  if(previous.root==root&&previous.kind==k)score+=0.35;
  for(int i=0;i<12;++i)score+=weight[i]*((wanted&(1u<<i))?0.15:-0.45);
  ranked.push_back({c,score});
  if(score>bestScore){bestScore=score;c.confidence=extras?0.65:0.95;best=c;}
 }
 if(conservative&&best.valid())for(auto&entry:ranked){auto&c=entry.first;if(c.root==best.root&&basicKind(c.kind)==basicKind(best.kind))continue;if(bestScore-entry.second<.8)return {};}
 return best;
}
struct Shape {std::array<int,6> fret;std::array<int,6> finger;bool valid=false;};
inline Shape fundamentalShape(const Chord&c){
 Shape s{{-1,-1,-1,-1,-1,-1},{0,0,0,0,0,0},false};
 if(!c.valid())return s;
 const int tuning[]={40,45,50,55,59,64};
 for(int string=0;string<6;++string){int fret=(c.root-tuning[string]%12+12)%12;
  if(fret<=4){s.fret[string]=fret;s.finger[string]=fret;s.valid=true;break;}
 }return s;
}
inline bool fundamentalKey(const Chord&c,int midiNote){return c.valid()&&midiNote==48+c.root;}
inline Shape shape(const Chord&c){
 if(!c.valid())return {{},{},false};
 struct Open {int root,kind;std::array<int,6> f,d;};
 static const Open o[]={
  {7,0,{3,2,0,0,3,3},{2,1,0,0,3,4}}, {0,0,{-1,3,2,0,1,0},{0,3,2,0,1,0}},
  {2,0,{-1,-1,0,2,3,2},{0,0,0,1,3,2}}, {2,1,{-1,-1,0,2,3,1},{0,0,0,2,3,1}},
  {9,0,{-1,0,2,2,2,0},{0,0,1,2,3,0}}, {9,1,{-1,0,2,2,1,0},{0,0,2,3,1,0}},
  {4,0,{0,2,2,1,0,0},{0,2,3,1,0,0}}, {4,1,{0,2,2,0,0,0},{0,2,3,0,0,0}},
  {7,2,{3,2,0,0,0,1},{3,2,0,0,0,1}}, {0,2,{-1,3,2,3,1,0},{0,3,2,4,1,0}},
  {2,2,{-1,-1,0,2,1,2},{0,0,0,2,1,3}}, {11,2,{-1,2,1,2,0,2},{0,2,1,3,0,4}},
  {2,3,{-1,-1,0,2,1,1},{0,0,0,2,1,1}}, {2,4,{-1,-1,0,2,2,2},{0,0,0,1,1,1}},
  {0,4,{-1,3,2,0,0,0},{0,3,2,0,0,0}}, {2,5,{-1,-1,0,2,3,0},{0,0,0,1,3,0}},
  {2,6,{-1,-1,0,2,3,3},{0,0,0,1,3,4}}, {0,13,{-1,3,2,0,3,0},{0,2,1,0,3,0}}
 };
 for(auto&v:o)if(c.root==v.root&&c.kind==v.kind)return {v.f,v.d,true};
 // Movable A-family voicings. Repeated finger 1 means a barre.
 static const std::array<int,6> af[]={
  {-1,0,2,2,2,0},{-1,0,2,2,1,0},{-1,0,2,0,2,0},{-1,0,2,0,1,0},
  {-1,0,2,1,2,0},{-1,0,2,2,0,0},{-1,0,2,2,3,0},{-1,0,1,2,1,-1},
  {-1,0,3,2,2,-1},{-1,0,1,0,1,-1},{-1,0,1,2,1,2},{-1,0,2,2,2,2},
  {-1,0,2,2,1,2}
 };
 static const std::array<int,6> ad[]={
  {0,1,2,3,4,1},{0,1,3,4,2,1},{0,1,3,1,4,1},{0,1,3,1,2,1},
  {0,1,3,2,4,1},{0,1,3,4,1,1},{0,1,3,3,4,1},{0,1,2,4,3,0},
  {0,1,4,2,3,0},{0,1,2,1,3,0},{0,1,2,3,2,4},{0,1,3,3,3,3},
  {0,1,3,3,2,4}
 };
 if(c.kind>=13)return {{},{},false};
 int shift=(c.root-9+12)%12;Shape s{af[c.kind],ad[c.kind],true};
 // Shorter, familiar E-family shapes for major/minor/dominant/minor 7.
 int eshift=(c.root-4+12)%12;
 if(c.kind<4&&eshift<shift){
  static const std::array<int,6> ef[]={ {0,2,2,1,0,0},{0,2,2,0,0,0},{0,2,0,1,0,0},{0,2,0,0,0,0} };
  static const std::array<int,6> ed[]={ {1,3,4,2,1,1},{1,3,4,1,1,1},{1,3,1,2,1,1},{1,3,1,1,1,1} };
  s={ef[c.kind],ed[c.kind],true};shift=eshift;
 }
 for(int i=0;i<6;++i){if(s.fret[i]>=0){s.fret[i]+=shift;if(s.fret[i]==0)s.finger[i]=0;}}
 return s;
}
}
