"""Build a native .lyt theme without changing any control coordinates."""
from pathlib import Path
import io
import struct
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent.parent
TARGET = ROOT if (ROOT/'vmidi.exe').exists() else ROOT / 'work' / "vanBasco's Karaoke Player"
ORIGINAL = ROOT / 'upload' / "vanBasco's Karaoke Player.zip"

def checksum(data):
    value = 0x504D4276
    for (word,) in struct.iter_unpack('<I', data[:len(data)//4*4]):
        value = ((value + word) & 0xFFFFFFFF) ^ word
    return value

def recolor(rgb):
    r,g,b = rgb
    lo, hi = min(rgb), max(rgb)
    if hi < 12: return (9,15,23)
    if g > 150 and b > 130 and r < g*.65: return (106,237,197)
    if r > 60 and r > g*1.55 and r > b*1.35: return (min(244,r+35),74,96)
    if g > r*1.5 and g > b*1.5: return (56,min(220,g+25),150)
    if r > 65 and g > 55 and b < min(r,g)*.6: return (199,153,69)
    if lo > 205: return (23,31,41)
    if hi > 175 and lo > 140: return (29,41,54)
    if hi > 115 and lo > 70: return (48,66,83)
    if hi > 55 and b > r*1.25: return (83,117,137)
    return (186,204,217)

def modern_bitmap(data,kind):
    original = Image.open(io.BytesIO(data)).convert('RGB')
    # Generate exact-size UI sprite assets, keeping existing button glyphs.
    im = original.copy()
    im.putdata([recolor(c) for c in original.getdata()])
    d = ImageDraw.Draw(im)
    fontpath=next(p for p in ['C:/Windows/Fonts/segoeui.ttf','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'] if Path(p).exists())
    boldpath=next(p for p in ['C:/Windows/Fonts/segoeuib.ttf','/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'] if Path(p).exists())
    font=ImageFont.truetype(boldpath,11)
    titles={1:('vanBasco',30,303),3:('MIDI / CANAIS',8,485),5:('PIANO',8,643),9:('CONTROLE',8,120)}
    if kind in titles:
        label,x,end=titles[kind]
        d.rectangle((x,2,end,25),fill=(23,31,41))
        d.text((x+1,6),label,font=font,fill=(225,237,244))
    if kind==1:
        d.text((106,7),'KARAOKE PLAYER',font=ImageFont.truetype(fontpath,9),fill=(106,237,197))
        def transport(x,y,w,h,symbol,active=False):
            d.rounded_rectangle((x,y,x+w-1,y+h-1),radius=3,fill=(51,104,98) if active else (40,60,75))
            cx,cy=x+w/2,y+h/2;ink=(106,237,197)
            if symbol=='stop':d.rectangle((cx-3,cy-3,cx+3,cy+3),fill=ink)
            elif symbol=='pause':
                for a in [-4,2]:d.rectangle((cx+a,cy-4,cx+a+2,cy+4),fill=ink)
            else:
                direction=-1 if symbol in ('rew','prev') else 1
                def triangle(center):d.polygon([(center-direction*3,cy-4),(center-direction*3,cy+4),(center+direction*4,cy)],fill=ink)
                if symbol in ('rew','ff'):
                    triangle(cx-4);triangle(cx+4)
                else:
                    triangle(cx)
                    if symbol in ('prev','next'):d.rectangle((cx+direction*6-1,cy-4,cx+direction*6+1,cy+4),fill=ink)
        for x,w,symbol in [(24,44,'rew'),(71,44,'ff'),(118,44,'play'),(165,44,'stop'),(213,31,'prev'),(249,31,'next')]:
            for y in [130,280,320]:transport(x,y,w,18,symbol,y==320)
        for x in [158,204,250]:transport(x,240,44,18,'pause',x==250)
    if kind==1:
        small=ImageFont.truetype(boldpath,8)
        for y in [179,343,357,371]:
            d.rectangle((17,y,62,y+10),fill=(23,31,41))
            d.text((22,y-1),'LISTA',font=small,fill=(225,237,244))
    if kind==5:
        im.paste(original.crop((14,31,688,63)),(14,31))
    # Each bitmap retains its 8-bit depth, palette size, dimensions and stride.
    out=io.BytesIO();indexed=im.quantize(colors=256)
    indexed.putpalette((indexed.getpalette()+[0]*768)[:768])
    indexed.save(out,format='BMP')
    return out.getvalue()

def build():
    import zipfile
    if (TARGET/'Original.lyt').exists():
        source=(TARGET/'Original.lyt').read_bytes()
    else:
        with zipfile.ZipFile(ORIGINAL) as z:
            source=z.read("vanBasco's Karaoke Player/default.lyt")
    (TARGET/'Original.lyt').write_bytes(source)
    out=bytearray(source[:2]);p=2;changed=0
    while p+10<len(source):
        kind,size,check=struct.unpack_from('<HII',source,p)
        data=source[p+10:p+10+size]
        assert checksum(data)==check
        if data.startswith(b'BM'):
            data=modern_bitmap(data,kind);changed+=1
        out+=struct.pack('<HII',kind,len(data),checksum(data))+data
        p+=10+size
    out+=source[p:]
    (TARGET/'default.lyt').write_bytes(out)
    (TARGET/'Moderno.lyt').write_bytes(out)
    print('Generated',changed,'UI sprite atlases. Control definitions unchanged.')
    # Native main window sprite preview, for internal QA.
    (ROOT/'inspect').mkdir(exist_ok=True)
    Image.open(io.BytesIO(out[768:146606])).save(ROOT/'inspect'/'skin-preview.png')

if __name__=='__main__':build()
