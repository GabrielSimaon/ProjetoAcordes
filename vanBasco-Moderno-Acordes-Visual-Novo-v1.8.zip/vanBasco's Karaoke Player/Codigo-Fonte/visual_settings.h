#pragma once
#include <windows.h>
#include <string>
#include <vector>
namespace visual {
constexpr const wchar_t* key=L"Software\\vanBasco\\vanBasco's MIDI Player\\Karaoke Window";
constexpr const wchar_t* backup=L"Software\\vanBasco\\AcordesCompanion\\VisualBackupV2";
struct Setting {std::wstring name;DWORD type;std::vector<BYTE> bytes;};
inline Setting str(const std::wstring&name,const std::wstring&value){auto*p=(const BYTE*)value.c_str();return {name,REG_SZ,std::vector<BYTE>(p,p+(value.size()+1)*sizeof(wchar_t))};}
inline Setting number(const std::wstring&name,DWORD v){auto*p=(BYTE*)&v;return {name,REG_DWORD,std::vector<BYTE>(p,p+4)};}
inline std::vector<Setting> palette(){
 std::vector<Setting>s={str(L"FontName",L"Segoe UI"),number(L"FontWeight",600),number(L"FontItalic",0),number(L"Outline",0),number(L"CenterText",1),str(L"Bitmap",L"")};
 COLORREF colors[]={RGB(236,243,247),RGB(14,19,26),RGB(106,237,197),RGB(14,19,26),RGB(144,161,179),RGB(14,19,26),RGB(236,243,247),RGB(14,19,26),RGB(14,19,26),RGB(144,161,179)};
 for(int i=0;i<10;++i){wchar_t hex[24];swprintf(hex,24,L"0x%06lx",(unsigned long)colors[i]);s.push_back(str(L"Color"+std::to_wstring(i),hex));}return s;
}
inline bool apply(){
 HKEY native=nullptr,saved=nullptr;if(RegCreateKeyExW(HKEY_CURRENT_USER,backup,0,nullptr,0,KEY_READ|KEY_WRITE,nullptr,&saved,nullptr)!=ERROR_SUCCESS)return false;
 DWORD done=0,n=4;RegQueryValueExW(saved,L"Applied",nullptr,nullptr,(BYTE*)&done,&n);if(done){RegCloseKey(saved);return true;}
 if(RegCreateKeyExW(HKEY_CURRENT_USER,key,0,nullptr,0,KEY_READ|KEY_WRITE,nullptr,&native,nullptr)!=ERROR_SUCCESS){RegCloseKey(saved);return false;}
 bool ok=true;
 for(auto&s:palette()){
  // Commit a per-value backup before writing. Retries never overwrite backups.
  DWORD exists=0,len=4;std::wstring marker=s.name+L".Exists";
  if(RegQueryValueExW(saved,marker.c_str(),nullptr,nullptr,(BYTE*)&exists,&len)!=ERROR_SUCCESS){
   DWORD type=0,bytes=0;LSTATUS r=RegQueryValueExW(native,s.name.c_str(),nullptr,&type,nullptr,&bytes);
   if(r!=ERROR_SUCCESS&&r!=ERROR_FILE_NOT_FOUND){ok=false;break;}
   if(r==ERROR_SUCCESS){std::vector<BYTE> data(bytes);if(RegQueryValueExW(native,s.name.c_str(),nullptr,&type,data.data(),&bytes)!=ERROR_SUCCESS||RegSetValueExW(saved,s.name.c_str(),0,type,data.data(),bytes)!=ERROR_SUCCESS){ok=false;break;}exists=1;}
   if(RegSetValueExW(saved,marker.c_str(),0,REG_DWORD,(BYTE*)&exists,4)!=ERROR_SUCCESS){ok=false;break;}
  }
  if(RegSetValueExW(native,s.name.c_str(),0,s.type,s.bytes.data(),(DWORD)s.bytes.size())!=ERROR_SUCCESS){ok=false;break;}
 }
 if(ok){done=1;ok=RegSetValueExW(saved,L"Applied",0,REG_DWORD,(BYTE*)&done,4)==ERROR_SUCCESS;}
 RegCloseKey(native);RegCloseKey(saved);return ok;
}
inline bool restore(){
 HKEY saved=nullptr,native=nullptr;if(RegOpenKeyExW(HKEY_CURRENT_USER,backup,0,KEY_READ|KEY_WRITE,&saved)!=ERROR_SUCCESS)return false;
 if(RegCreateKeyExW(HKEY_CURRENT_USER,key,0,nullptr,0,KEY_READ|KEY_WRITE,nullptr,&native,nullptr)!=ERROR_SUCCESS){RegCloseKey(saved);return false;}
 bool ok=true;
 for(auto&s:palette()){
  DWORD exists=0,n=4;if(RegQueryValueExW(saved,(s.name+L".Exists").c_str(),nullptr,nullptr,(BYTE*)&exists,&n)!=ERROR_SUCCESS)continue;
  if(exists){DWORD type=0,bytes=0;if(RegQueryValueExW(saved,s.name.c_str(),nullptr,&type,nullptr,&bytes)!=ERROR_SUCCESS){ok=false;continue;}std::vector<BYTE> data(bytes);if(RegQueryValueExW(saved,s.name.c_str(),nullptr,&type,data.data(),&bytes)!=ERROR_SUCCESS||RegSetValueExW(native,s.name.c_str(),0,type,data.data(),bytes)!=ERROR_SUCCESS)ok=false;}
  else{LSTATUS r=RegDeleteValueW(native,s.name.c_str());if(r!=ERROR_SUCCESS&&r!=ERROR_FILE_NOT_FOUND)ok=false;}
 }
 // Keep Applied=1: the restored user choices must not be reset next launch.
 RegCloseKey(native);RegCloseKey(saved);return ok;
}
}
