#pragma once
#include <vector>
#include <algorithm>
#include "playlist_search.h"
namespace playlist_ui {
constexpr int editId=0x7d10,searchId=0x7d11,clearId=0x7d12,titleId=0x7d13,statusId=0x7d14,subtitleId=0x7d15;
constexpr const wchar_t* prop=L"Acordes.Playlist15";
struct ChildPos{HWND h;RECT r;};
struct State{HWND edit{},search{},clear{},title{},status{},subtitle{};std::vector<ChildPos> native;int last=-1;std::wstring query;bool arranging=false,enlarged=false;};
inline State* get(HWND h){return (State*)GetPropW(h,prop);}
inline bool ours(HWND h){int id=GetDlgCtrlID(h);return id>=editId&&id<=subtitleId;}
inline std::wstring translated(std::wstring s){
 static const std::pair<const wchar_t*,const wchar_t*> words[]={
 {L"Playlist",L"Lista de músicas"},{L"Playlist Window",L"Lista de músicas"},{L"Name",L"Nome"},{L"Filename",L"Arquivo"},{L"File Name",L"Arquivo"},{L"Length",L"Duração"},{L"Time",L"Tempo"},{L"Title",L"Título"},{L"Path",L"Pasta"},
 {L"Create new list",L"Criar uma lista"},{L"Rename current list",L"Renomear a lista"},{L"Delete current list",L"Excluir a lista"},{L"Position up",L"Mover para cima"},{L"Position down",L"Mover para baixo"},{L"Sort List",L"Ordenar lista"},{L"Play selected song",L"Tocar a música selecionada"},{L"Add selected songs to list",L"Adicionar as selecionadas"},{L"Add all songs to list",L"Adicionar todas"},{L"Remove selected songs from list",L"Remover as selecionadas"},{L"Remove all songs from list",L"Remover todas"},{L"Up one level",L"Voltar uma pasta"},
 {L"Play",L"Tocar"},{L"Remove",L"Remover"},{L"Remove All",L"Remover todas"},{L"Add",L"Adicionar"},{L"Add All",L"Adicionar todas"},{L"New",L"Nova lista"},{L"Rename",L"Renomear"},{L"Delete",L"Excluir"},{L"Sort",L"Ordenar"},{L"Select All",L"Selecionar todas"},{L"empty",L"esvaziar"},{L"up",L"subir"},{L"down",L"descer"}};
 auto key=s;key.erase(std::remove(key.begin(),key.end(),L'&'),key.end());for(auto&p:words)if(key==p.first)return p.second;return s;
}
inline BOOL CALLBACK listChild(HWND h,LPARAM p){wchar_t c[64]{};GetClassNameW(h,c,64);if(std::wstring(c)==WC_LISTVIEWW&&IsWindowVisible(h))((std::vector<HWND>*)p)->push_back(h);return TRUE;}
inline std::vector<HWND> lists(HWND parent){std::vector<HWND> out;EnumChildWindows(parent,listChild,(LPARAM)&out);return out;}
inline void setStatus(State*s,const std::wstring&v){SetWindowTextW(s->status,v.c_str());}
inline std::wstring cell(HWND list,int row,int col){
 if(IsWindowUnicode(list)){wchar_t text[1024]{};LVITEMW item{};item.iSubItem=col;item.pszText=text;item.cchTextMax=1024;SendMessageW(list,LVM_GETITEMTEXTW,row,(LPARAM)&item);return text;}
 char text[1024]{};LVITEMA item{};item.iSubItem=col;item.pszText=text;item.cchTextMax=1024;SendMessageA(list,LVM_GETITEMTEXTA,row,(LPARAM)&item);int n=MultiByteToWideChar(CP_ACP,0,text,-1,nullptr,0);std::wstring out(n>0?n:0,L'\0');if(n>0)MultiByteToWideChar(CP_ACP,0,text,-1,&out[0],n);if(!out.empty()&&out.back()==L'\0')out.pop_back();return out;
}
inline void search(HWND h){auto*s=get(h);if(!s)return;wchar_t q[256]{};GetWindowTextW(s->edit,q,256);auto needle=playlist_search::fold(q);if(needle.empty()){setStatus(s,L"Digite o nome da música ou do arquivo");return;}
 if(needle!=s->query){s->query=needle;s->last=-1;}
 struct Match{HWND list;int row;};std::vector<Match> matches;
 for(HWND list:lists(h)){int n=ListView_GetItemCount(list);for(int row=0;row<n;++row){std::wstring line;for(int col=0;col<4;++col){line+=cell(list,row,col);line+=L' ';}if(playlist_search::matches(line,needle))matches.push_back({list,row});}}
 if(matches.empty()){setStatus(s,L"Nenhuma música encontrada");s->last=-1;return;}
 s->last=(s->last+1)%int(matches.size());auto found=matches[s->last];for(HWND list:lists(h))ListView_SetItemState(list,-1,0,LVIS_SELECTED|LVIS_FOCUSED);ListView_SetItemState(found.list,found.row,LVIS_SELECTED|LVIS_FOCUSED,LVIS_SELECTED|LVIS_FOCUSED);ListView_EnsureVisible(found.list,found.row,FALSE);SetFocus(found.list);
 setStatus(s,std::to_wstring(s->last+1)+L" de "+std::to_wstring(matches.size())+L" resultados · clique novamente para avançar");
}
inline LRESULT CALLBACK editProc(HWND h,UINT m,WPARAM w,LPARAM l){auto*s=window_style::get(h);if(!s)return DefWindowProcW(h,m,w,l);if(m==WM_NCDESTROY)return window_style::destroy(h,editProc,m,w,l);if(m==WM_KEYDOWN&&w==VK_RETURN){search(GetParent(h));return 0;}if(m==WM_KEYDOWN&&w==VK_ESCAPE){SetWindowTextW(h,L"");if(auto*p=get(GetParent(h))){p->query.clear();p->last=-1;setStatus(p,L"Pesquisa limpa");}return 0;}return window_style::forward(*s,h,m,w,l);}
inline void restore(HWND h){auto*s=get(h);if(!s||s->arranging)return;s->arranging=true;for(auto&c:s->native)if(IsWindow(c.h))SetWindowPos(c.h,nullptr,c.r.left,c.r.top,c.r.right-c.r.left,c.r.bottom-c.r.top,SWP_NOZORDER|SWP_NOACTIVATE);s->native.clear();s->arranging=false;}
inline void place(HWND h){auto*s=get(h);if(!s||s->arranging||!s->native.empty())return;s->arranging=true;s->native.clear();for(HWND child=GetWindow(h,GW_CHILD);child;child=GetWindow(child,GW_HWNDNEXT)){if(ours(child))continue;RECT r;GetWindowRect(child,&r);MapWindowPoints(nullptr,h,(POINT*)&r,2);s->native.push_back({child,r});}RECT client{};GetClientRect(h,&client);int width=client.right,height=client.bottom;constexpr int header=102;
 for(auto&c:s->native){if(!IsWindow(c.h))continue;wchar_t cls[64]{};GetClassNameW(c.h,cls,64);int y=c.r.top,ht=c.r.bottom-c.r.top;bool status=std::wstring(cls)==STATUSCLASSNAMEW;
  if(status)continue;if(y<height-28){y+=header;if(ht>90||c.r.bottom>height-35)ht=std::max(24,ht-header);SetWindowPos(c.h,nullptr,c.r.left,y,c.r.right-c.r.left,ht,SWP_NOZORDER|SWP_NOACTIVATE);}
 }
 SetWindowPos(s->title,HWND_TOP,18,10,300,28,SWP_NOACTIVATE|SWP_SHOWWINDOW);SetWindowPos(s->subtitle,HWND_TOP,19,38,std::max(100,width-38),18,SWP_NOACTIVATE|SWP_SHOWWINDOW);
 int button=100,clear=36;SetWindowPos(s->edit,HWND_TOP,18,63,std::max(100,width-18*2-button-clear-12),31,SWP_NOACTIVATE|SWP_SHOWWINDOW);SetWindowPos(s->search,HWND_TOP,width-button-clear-24,63,button,31,SWP_NOACTIVATE|SWP_SHOWWINDOW);SetWindowPos(s->clear,HWND_TOP,width-clear-18,63,clear,31,SWP_NOACTIVATE|SWP_SHOWWINDOW);SetWindowPos(s->status,HWND_TOP,std::max(330,width-310),13,292,20,SWP_NOACTIVATE|SWP_SHOWWINDOW);
 s->arranging=false;InvalidateRect(h,nullptr,TRUE);
}
inline void attach(HWND h,HFONT font,HINSTANCE module){if(get(h)){place(h);return;}auto*s=new State{};if(!SetPropW(h,prop,s)){delete s;return;}
 SetWindowTextW(h,L"Lista de músicas · vanBasco");
 s->title=CreateWindowW(L"STATIC",L"LISTA DE MÚSICAS",WS_CHILD|SS_LEFT,0,0,1,1,h,(HMENU)titleId,module,nullptr);
 s->subtitle=CreateWindowW(L"STATIC",L"Organize suas listas à esquerda e escolha os arquivos à direita.",WS_CHILD|SS_LEFT,0,0,1,1,h,(HMENU)subtitleId,module,nullptr);
 s->status=CreateWindowW(L"STATIC",L"Pesquise nas duas colunas",WS_CHILD|SS_RIGHT,0,0,1,1,h,(HMENU)statusId,module,nullptr);
 s->edit=CreateWindowExW(WS_EX_CLIENTEDGE,L"EDIT",L"",WS_CHILD|WS_TABSTOP|ES_AUTOHSCROLL,0,0,1,1,h,(HMENU)editId,module,nullptr);SendMessageW(s->edit,EM_LIMITTEXT,255,0);SendMessageW(s->edit,EM_SETCUEBANNER,TRUE,(LPARAM)L"Pesquisar música ou arquivo…");
 s->search=CreateWindowW(L"BUTTON",L"Pesquisar",WS_CHILD|WS_TABSTOP|BS_OWNERDRAW,0,0,1,1,h,(HMENU)searchId,module,nullptr);s->clear=CreateWindowW(L"BUTTON",L"×",WS_CHILD|WS_TABSTOP|BS_OWNERDRAW,0,0,1,1,h,(HMENU)clearId,module,nullptr);
 for(HWND child:{s->title,s->subtitle,s->status,s->edit,s->search,s->clear})SendMessageW(child,WM_SETFONT,(WPARAM)font,TRUE);window_style::install(s->edit,editProc,4);
 RECT wr;GetWindowRect(h,&wr);RECT work;SystemParametersInfoW(SPI_GETWORKAREA,0,&work,0);int workW=int(work.right-work.left),workH=int(work.bottom-work.top),oldW=int(wr.right-wr.left),oldH=int(wr.bottom-wr.top);int w=std::min(760,workW),ht=std::min(500,workH);if(oldW<w||oldH<ht){int x=std::max(int(work.left),std::min(int(wr.left),int(work.right)-w)),y=std::max(int(work.top),std::min(int(wr.top),int(work.bottom)-ht));SetWindowPos(h,nullptr,x,y,std::max(w,oldW),std::max(ht,oldH),SWP_NOZORDER|SWP_NOACTIVATE);s->enlarged=true;}
 place(h);
}
inline bool command(HWND h,WPARAM w){auto*s=get(h);if(!s)return false;int id=LOWORD(w);if(id==searchId){search(h);return true;}if(id==clearId){SetWindowTextW(s->edit,L"");s->last=-1;s->query.clear();setStatus(s,L"Pesquisa limpa");SetFocus(s->edit);return true;}return id==editId;}
inline bool draw(DRAWITEMSTRUCT*d,HFONT font){if(d->CtlID!=searchId&&d->CtlID!=clearId)return false;RECT r=d->rcItem;HBRUSH brush=CreateSolidBrush(d->CtlID==searchId?RGB(106,237,197):RGB(35,46,60));FillRect(d->hDC,&r,brush);DeleteObject(brush);SetBkMode(d->hDC,TRANSPARENT);SetTextColor(d->hDC,d->CtlID==searchId?RGB(14,19,26):RGB(236,243,247));auto old=SelectObject(d->hDC,font);wchar_t text[40]{};GetWindowTextW(d->hwndItem,text,40);DrawTextW(d->hDC,text,-1,&r,DT_CENTER|DT_VCENTER|DT_SINGLELINE);SelectObject(d->hDC,old);if(d->itemState&ODS_FOCUS){InflateRect(&r,-3,-3);DrawFocusRect(d->hDC,&r);}return true;}
inline void menu(HMENU m){int n=GetMenuItemCount(m);for(int i=0;i<n;++i){wchar_t buf[512]{};MENUITEMINFOW x{};x.cbSize=sizeof x;x.fMask=MIIM_STRING|MIIM_SUBMENU;x.dwTypeData=buf;x.cch=512;if(!GetMenuItemInfoW(m,i,TRUE,&x))continue;auto label=translated(buf);if(label!=buf){x.fMask=MIIM_STRING;x.dwTypeData=&label[0];SetMenuItemInfoW(m,i,TRUE,&x);}if(x.hSubMenu)menu(x.hSubMenu);}}
inline void destroy(HWND h){auto*s=get(h);RemovePropW(h,prop);delete s;}
}
