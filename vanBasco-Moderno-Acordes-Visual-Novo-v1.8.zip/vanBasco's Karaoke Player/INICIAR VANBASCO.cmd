@echo off
setlocal
cd /d "%~dp0"
rem Remove a marca de download apenas dos binarios verificados deste pacote.
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "Unblock-File -LiteralPath '.\Acordes.exe'; Unblock-File -LiteralPath '.\VisualModerno.dll'; Unblock-File -LiteralPath '.\vmidi.exe'" >nul 2>&1
start "" "%CD%\Acordes.exe"
exit /b
